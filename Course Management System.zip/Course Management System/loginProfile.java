package AssignmentJava2;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class loginProfile extends JFrame implements ActionListener,ItemListener{
    private JPanel mainPanel,p1,p3,pp3,p4,pAll,rdbP,pT;
    private JButton btnLogin;
    private JLabel lbl_Login,lblSp;
    private JRadioButton rdbStudent,rdbLecturer;
    private String profileIdentifier;

    public static void main(String [] args){
        loginProfile frame = new loginProfile();
        frame.setTitle("Login Profile");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public loginProfile(){
        lbl_Login = new JLabel("LOGIN");
        Font myFont = new Font("SansSerif ", Font.BOLD, 35);
        lblSp = new JLabel("Select Profile");
        Font myFont2 = new Font("SansSerif ", Font.BOLD, 25);
        rdbStudent = new JRadioButton("Student");
        rdbLecturer = new JRadioButton("Lecturer");
        btnLogin = new JButton("Login");
            btnLogin.addActionListener(this);
        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.CENTER,5,0));
        p1.add(lblSp);
            lblSp.setFont(myFont2);
        rdbP = new JPanel();
        rdbP.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        rdbP.add(rdbStudent);
        rdbP.add(rdbLecturer);
            rdbStudent.addItemListener(this);
            rdbLecturer.addItemListener(this);
        ButtonGroup bg = new ButtonGroup();
        bg.add(rdbStudent);
        bg.add(rdbLecturer);
        pp3 = new JPanel();
        pp3.setLayout(new GridLayout(1,2));
        pp3.add(rdbP);
        p3 = new JPanel();
        p3.setLayout(new FlowLayout(FlowLayout.CENTER,5,0));
        p3.add(pp3);
        p4 = new JPanel();
        p4.setLayout(new FlowLayout(FlowLayout.CENTER,5,0));
        p4.add(btnLogin);
        pAll = new JPanel();
        pAll.setLayout(new GridLayout(5,1));
        pAll.add(p1);
        pAll.add(p3);
        pAll.add(p4);
        pT = new JPanel();
        pT.setLayout(new FlowLayout(FlowLayout.CENTER,5,0));
        pT.add(lbl_Login);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(pT,BorderLayout.NORTH);
            lbl_Login.setFont(myFont);
        mainPanel.add(pAll);
        add(mainPanel);
    }

    public void itemStateChanged(ItemEvent e){
        if(rdbStudent.isSelected()){
            System.out.println("Student Profile is Selected");
            profileIdentifier = "Student";
        }else if(rdbLecturer.isSelected()){
            System.out.println("Lecturer Profile is Selected");
            profileIdentifier = "Lecturer";
        }
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnLogin){
            if(profileIdentifier=="Student"){
                studentLogin p1 = new studentLogin();
                p1.setTitle("Student Login");
                p1.setVisible(true);
                p1.setSize(800,350);
                p1.setLocationRelativeTo(null);
                dispose();
            }else if(profileIdentifier=="Lecturer"){
                lecturerLogin p2 = new lecturerLogin();
                p2.setTitle("Lecturer Login");
                p2.setVisible(true);
                p2.setSize(800,350);
                p2.setLocationRelativeTo(null);
                dispose();
            }
        }
    }
}
