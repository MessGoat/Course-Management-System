package AssignmentJava2;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;


public class lecturerStuList extends JFrame implements ActionListener {
    private JPanel sidePanel,mainPanel,pBtn,pAll,pTitle,pp1;
    private JButton btnLPf,btnLC,btnLogOut,btnMarkA;
    private JLabel lbl_slTitle,lblStuList,lblcoursetitle;
    private JTable jtStuList;
    private JScrollPane sp1;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        lecturerStuList frame = new lecturerStuList();
        frame.setTitle("Student List");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }
    
    public lecturerStuList(){
        lbl_slTitle = new JLabel("Student List");
        btnLPf = new JButton("Profile");
        btnLC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        btnLPf.addActionListener(this);
        btnLC.addActionListener(this);
        btnLogOut.addActionListener(this);
        lblStuList = new JLabel("Student List");
        btnMarkA = new JButton("Mark Attendance");
        btnMarkA.addActionListener(this);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(3,1));
        sidePanel.add(btnLPf);
        sidePanel.add(btnLC);
        sidePanel.add(btnLogOut);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        String [][] stuData = {
            {"1.","2022000001","12"},
            {"2.","2022000003","1"},
        };
        String [] format ={"No.","Student ID","Attendance"};
        jtStuList = new JTable(stuData,format);
        sp1 = new JScrollPane(jtStuList);
        sp1.setBorder(new LineBorder(Color.gray,2));
        pBtn = new JPanel();
        pBtn.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pBtn.add(btnMarkA);
        pTitle = new JPanel();
        pTitle.setLayout(new FlowLayout(FlowLayout.LEFT));
        pTitle.add(lblStuList);
        pp1 = new JPanel();
        pp1.setLayout(new BorderLayout());
        pp1.add(pTitle,BorderLayout.NORTH); 
        pp1.add(sp1); 
        pAll = new JPanel();
        pAll.setLayout(new BorderLayout());
        pAll.add(sp1);
        pAll.add(pBtn,BorderLayout.SOUTH);
        mainPanel = new JPanel();
        mainPanel.add(lbl_slTitle);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_slTitle,BorderLayout.NORTH);
            lbl_slTitle.setFont(myFont);
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnLPf){
            String courseid = lblcoursetitle.getText();
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT u.Fname,u.Lname,u.ContactNo,u.Email,u.Address,u.IC,u.Gender,u.ResgistrationDate,l.LecturerID,l.Position,l.SchoolEmail,l.Department,l.Salary FROM userprofile u,lecturer l,course c WHERE u.IC = l.IC AND l.LecturerID = c.LecturerID AND CourseID =?");
                stmt.setString(1, courseid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String lecturerID = rs.getString("LecturerID");
                    String position = rs.getString("Position");
                    String schoolEmail = rs.getString("SchoolEmail");
                    String department = rs.getString("Department");
                    String salary = rs.getString("Salary");

                    lecturerProfile p1 = new lecturerProfile(firstName, lastName, gender, contactNo, email, ic, lecturerID, position, schoolEmail, department, salary);
                    p1.setTitle("Lecturer Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLC){
            String cid = lblcoursetitle.getText();
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT c.CourseID, c.CourseName, c.CreditHours, c.LecturerID FROM Course c,Lecturer l,userprofile p WHERE p.IC = l.IC AND l.LecturerID = c.LecturerID AND c.CourseID=?");
                stmt.setString(1, cid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String courseID = rs.getString("CourseID");
                    String courseName = rs.getString("CourseName");
                    int creditHour = rs.getInt("CreditHours");
                    String id = rs.getString("LecturerID");

                    lecturerCourse p1 = new lecturerCourse(id);
                    p1.setTitle("Lecturer Course");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            lecturerLogin p4 = new lecturerLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
        if(e.getSource()==btnMarkA){
            String cid = lblcoursetitle.getText();
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM StudentCourse WHERE CourseID=?");
                stmt.setString(1, cid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String id = rs.getString("CourseID");

                    lecturerMAttendance p1 = new lecturerMAttendance(cid);
                    p1.setTitle("Student List");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
    }
    
    public lecturerStuList(String courseid) {
        try {
            Connect_DB();

            PreparedStatement stmt = conn.prepareStatement("SELECT StudentID, COUNT(*) AS AttendanceCount FROM StudentCourse WHERE CourseID=? AND Attendance=1 GROUP BY StudentID");
            stmt.setString(1, courseid);
            ResultSet rs = stmt.executeQuery();
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("No.");
            model.addColumn("Student ID");
            model.addColumn("AttendanceCount");
            int row = 1;
            while (rs.next()) {
                String id = rs.getString("StudentID");
                int attendance = rs.getInt("AttendanceCount");
                model.addRow(new Object[]{row, id, attendance});
                row++;
            }
            lblcoursetitle = new JLabel(courseid);
            lbl_slTitle = new JLabel(" Student List");
            btnLPf = new JButton("Profile");
            btnLC = new JButton("Course");
            btnLogOut = new JButton("Log Out");
            btnLPf.addActionListener(this);
            btnLC.addActionListener(this);
            btnLogOut.addActionListener(this);
            lblStuList = new JLabel("Student List");
            btnMarkA = new JButton("Mark Attendance");
            btnMarkA.addActionListener(this);
            sidePanel = new JPanel();
            sidePanel.setLayout(new GridLayout(3,1));
            sidePanel.add(btnLPf);
            sidePanel.add(btnLC);
            sidePanel.add(btnLogOut);
            Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
            jtStuList = new JTable(model);
            JScrollPane sp1 = new JScrollPane(jtStuList);
            sp1.setBorder(BorderFactory.createLineBorder(Color.gray, 2));
            pBtn = new JPanel();
            pBtn.setLayout(new FlowLayout(FlowLayout.RIGHT));
            pBtn.add(btnMarkA);
            pTitle = new JPanel();
            pTitle.setLayout(new FlowLayout(FlowLayout.LEFT));
            pTitle.add(lblStuList);
            pp1 = new JPanel();
            pp1.setLayout(new BorderLayout());
            pp1.add(pTitle,BorderLayout.NORTH); 
            pp1.add(sp1); 
            pAll = new JPanel();
            pAll.setLayout(new BorderLayout());
            pAll.add(sp1);
            pAll.add(pBtn,BorderLayout.SOUTH);
            mainPanel = new JPanel();
            JPanel mainPanel2 = new JPanel();
            mainPanel2.setLayout(new FlowLayout(FlowLayout.LEFT,10,10));
            mainPanel2.add(lblcoursetitle);
            mainPanel2.add(lbl_slTitle);
            mainPanel.add(mainPanel2);
            mainPanel = new JPanel();
            mainPanel.setLayout(new BorderLayout());
            mainPanel.add(lbl_slTitle,BorderLayout.NORTH);
                lbl_slTitle.setFont(myFont);
            mainPanel.add(pAll);
            add(sidePanel,BorderLayout.WEST);
            add(mainPanel);

            conn.close();
        } catch (Exception ex1) {
            ex1.printStackTrace();
        }
    }
}
