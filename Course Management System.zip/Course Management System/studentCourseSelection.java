package AssignmentJava2;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.event.*; 

public class studentCourseSelection extends JFrame implements ActionListener,ListSelectionListener{
    private JPanel sidePanel,mainPanel,p1,pList,p2,pT,pM,pB,pAll;
    private JButton btnPf,btnBill,btnC,btnLogOut;
    private JLabel lblcsTitle,lblSubject,lbladd;
    private JList liSubject;
    private JButton btnSubmit;
    private String courseID,studentID;
    private JScrollPane sp1;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        studentCourseSelection frame = new studentCourseSelection();
        frame.setTitle("Course Selection");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
        
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }
    
    public studentCourseSelection(){
        lblcsTitle = new JLabel("Course Selection");
        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        lblSubject = new JLabel("Subjects");
        lbladd = new JLabel("Select to Add");
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        String [] subjects ={
            "Object-Oriented Programming (DIT2274)",
            "Philosophy and Current Issues (MPU2153)",
            "Multimedia Programming (DIT2244)",
            "Object-Oriented System Analysis & Design (DIT2254)"
        };
        liSubject = new JList(subjects);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);
        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.LEFT));
        p1.add(lblSubject);
        p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.RIGHT));
        p2.add(lbladd);
        pList = new JPanel();
        pList.setLayout(new GridLayout(1,1));
        pList.add(liSubject);
        pB = new JPanel();
        pB.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pB.add(btnSubmit);
        pT = new JPanel();
        pT.setLayout(new GridLayout(1,2));
        pT.add(p1);
        pT.add(p2);
        pM = new JPanel();
        pM.setLayout(new BorderLayout());
        pM.add(pT,BorderLayout.NORTH);
        pM.add(pList);
        pAll = new JPanel();
        pAll.setLayout(new BorderLayout());
        pAll.add(pM);
        pAll.add(pB,BorderLayout.SOUTH);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lblcsTitle,BorderLayout.NORTH);
            lblcsTitle.setFont(myFont);
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnPf){
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM userprofile u,student s,studentcourse c WHERE u.IC=s.IC AND s.StudentID=c.StudentID AND c.StudentID=?");
                stmt.setString(1, studentID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String studentID = rs.getString("StudentID");
                    String intake = rs.getString("SemIntake");
                    String club = rs.getString("Club");
                    double scholarship = rs.getDouble("Scholarship");
                    String register = rs.getString("ResgistrationDate");
                    String address = rs.getString("Address");

                    studentProfile p1 = new studentProfile(firstName, lastName, gender, contactNo, email, ic, address, register, studentID, intake, club,scholarship);
                    p1.setTitle("Student Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnC){
            try{
                Connect_DB();
                studentCourse p1 = new studentCourse(studentID);
                p1.setTitle("Student Course");
                p1.setVisible(true);
                p1.setSize(800,350);
                p1.setLocationRelativeTo(null);
                dispose();
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnBill){
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Bill b,Student s,StudentCourse c WHERE b.StudentID = s.StudentID AND s.StudentID=c.StudentID AND c.StudentID=?");
                stmt.setString(1,studentID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String Invoice = rs.getString("Invoice");
                    double over = rs.getDouble("OverheadBill");
                    double paid = rs.getDouble("PaidBill");

                    studentBill p1 = new studentBill(studentID);
                    p1.setTitle("Student Bill");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            studentLogin p4 = new studentLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
        if(e.getSource() == btnSubmit){
            Object[] selectedSubjects = liSubject.getSelectedValues();
            updateDatabase(selectedSubjects);
        }
    }
    
    public studentCourseSelection(String courseID,String studentID){
        this.courseID = courseID;
        this.studentID = studentID;
        try{
            Connect_DB();

            PreparedStatement stmt = conn.prepareStatement("SELECT c.CourseID,c.CourseName FROM Course c ");
            ResultSet rs = stmt.executeQuery();
            DefaultListModel<String> model = new DefaultListModel<>();
            while (rs.next()) {
                String cid = rs.getString("CourseID");
                String cname = rs.getString("CourseName");
                model.addElement(cid+" : "+cname);
            }
            lblcsTitle = new JLabel("Course Selection");
            btnPf = new JButton("Profile");
            btnBill = new JButton("Bill");
            btnC = new JButton("Course");
            btnLogOut = new JButton("Log Out");
            Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
            btnPf.addActionListener(this);
            btnBill.addActionListener(this);
            btnC.addActionListener(this);
            btnLogOut.addActionListener(this);
            lblSubject = new JLabel("Subjects");
            lbladd = new JLabel("Select to Add");
            btnSubmit = new JButton("Submit");
            btnSubmit.addActionListener(this);
            liSubject = new JList<>(model);
            liSubject.setModel(model);
            sp1 = new JScrollPane(liSubject);
            sp1.setBorder(new LineBorder(Color.gray,2));
            liSubject.addListSelectionListener(this);
            sidePanel = new JPanel();
            sidePanel.setLayout(new GridLayout(4,1));
            sidePanel.add(btnPf);
            sidePanel.add(btnBill);
            sidePanel.add(btnC);
            sidePanel.add(btnLogOut);
            p1 = new JPanel();
            p1.setLayout(new FlowLayout(FlowLayout.LEFT));
            p1.add(lblSubject);
            p2 = new JPanel();
            p2.setLayout(new FlowLayout(FlowLayout.RIGHT));
            p2.add(lbladd);
            pList = new JPanel();
            pList.setLayout(new GridLayout(1,1));
            pList.add(liSubject);
            pB = new JPanel();
            pB.setLayout(new FlowLayout(FlowLayout.RIGHT));
            pB.add(btnSubmit);
            pT = new JPanel();
            pT.setLayout(new GridLayout(1,2));
            pT.add(p1);
            pT.add(p2);
            pM = new JPanel();
            pM.setLayout(new BorderLayout());
            pM.add(pT,BorderLayout.NORTH);
            pM.add(pList);
            pAll = new JPanel();
            pAll.setLayout(new BorderLayout());
            pAll.add(pM);
            pAll.add(pB,BorderLayout.SOUTH);
            mainPanel = new JPanel();
            mainPanel.setLayout(new BorderLayout());
            mainPanel.add(lblcsTitle,BorderLayout.NORTH);
                lblcsTitle.setFont(myFont);
            mainPanel.add(pAll);
            add(sidePanel,BorderLayout.WEST);
            add(mainPanel);

            conn.close();
        }catch(Exception ex1){
            ex1.printStackTrace();
        }
    }

    private void updateDatabase(Object[] selectedItems) {
        try {
            Connect_DB();

            PreparedStatement insertStmt = conn.prepareStatement("INSERT INTO StudentCourse (CourseID,StudentID) VALUES (?,?)");
            PreparedStatement checkStmt = conn.prepareStatement("SELECT * FROM StudentCourse WHERE CourseID = ? AND StudentID = ? AND Attendance IS NULL");
            for (Object selectedItem : selectedItems){
                String selectedCourseID = selectedItem.toString().split(":")[0].trim();
                checkStmt.setString(1, selectedCourseID);
                checkStmt.setString(2, studentID);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next()){
                    JOptionPane.showMessageDialog(null, "You have already taken the course.");
                }else{
                    insertStmt.setString(1, selectedCourseID);
                    insertStmt.setString(2, studentID);
                    insertStmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Succesfull added the course.");
                    insertStmt = conn.prepareStatement("INSERT INTO Grade VALUES (?,NULL,NULL,?)");
                    insertStmt.setString(1, selectedCourseID);
                    insertStmt.setString(2, studentID);
                    insertStmt.executeUpdate();
                }
            }
            conn.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    public void valueChanged(ListSelectionEvent e){
        if (!e.getValueIsAdjusting()){
            Object[] selectedItems = liSubject.getSelectedValues();
        }
    }
}