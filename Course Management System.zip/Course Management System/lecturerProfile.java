package AssignmentJava2;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class lecturerProfile extends JFrame implements ActionListener{
    private JPanel sidePanel,mainPanel,p1,p2,p3,p4,p5,p6,p7,pAll;
    private JButton btnLPf,btnLC,btnLogOut;
    private JLabel lbl_pTitle,lblFN,lblLN,lblGender,lblConNo,lblEmail,lblIC,lblLID,lblPosition,lblSchEmail,lblDepart,lblSalary;
    private JTextField tfFN,tfLN,tfConNo,tfEmail,tfIC,tfLID,tfPosition,tfSchEmail,tfDepart,tfSalary,tfGender;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        lecturerProfile frame = new lecturerProfile();
        frame.setTitle("Lecturer Profile");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public lecturerProfile(){
        lbl_pTitle = new JLabel("Profile");
        btnLPf = new JButton("Profile");
        btnLC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lblFN = new JLabel("First Name :");
        lblLN = new JLabel("Last Name :");
        lblGender = new JLabel("Gender :");
        lblConNo = new JLabel("Contact No :");
        lblEmail = new JLabel("Email :");
        lblIC= new JLabel("IC :");
        lblLID = new JLabel("Lecturer ID :");
        lblPosition = new JLabel("Position :");
        lblSchEmail = new JLabel("School Email :");
        lblDepart = new JLabel("Department :");
        lblSalary = new JLabel("Salary :");
        tfFN =new JTextField(15);
            tfFN.setEditable(false);
        tfLN =new JTextField(16);
            tfLN.setEditable(false);
        tfConNo =new JTextField(26);
            tfConNo.setEditable(false);
        tfEmail =new JTextField(42);
            tfEmail.setEditable(false);
        tfIC =new JTextField(44);
            tfIC.setEditable(false);
        tfLID =new JTextField(18);
            tfLID.setEditable(false);
        tfPosition =new JTextField(14);
            tfPosition.setEditable(false);
        tfSchEmail =new JTextField(38);
            tfSchEmail.setEditable(false);
        tfDepart =new JTextField(19);
            tfDepart.setEditable(false);
        tfSalary =new JTextField(14);
            tfSalary.setEditable(false);
        tfGender =new JTextField(14);
            tfGender.setEditable(false);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        btnLPf.addActionListener(this);
        btnLC.addActionListener(this);
        btnLogOut.addActionListener(this);
        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p1.add(lblFN);
        p1.add(tfFN);
        p1.add(lblLN);
        p1.add(tfLN);
        p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p2.add(lblGender);
        p2.add(tfGender);
        p2.add(lblConNo);
        p2.add(tfConNo);
        p3 = new JPanel();
        p3.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p3.add(lblEmail);
        p3.add(tfEmail);
        p4 = new JPanel();
        p4.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p4.add(lblIC);
        p4.add(tfIC);
        p5 = new JPanel();
        p5.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p5.add(lblLID);
        p5.add(tfLID);
        p5.add(lblPosition);
        p5.add(tfPosition);
        p6 = new JPanel();
        p6.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p6.add(lblSchEmail);
        p6.add(tfSchEmail);
        p7 = new JPanel();
        p7.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p7.add(lblDepart);
        p7.add(tfDepart);
        p7.add(lblSalary);
        p7.add(tfSalary);
        pAll = new JPanel();
        pAll.setLayout(new GridLayout(7,1));
        pAll.add(p1);
        pAll.add(p2);
        pAll.add(p3);
        pAll.add(p4);
        pAll.add(p5);
        pAll.add(p6);
        pAll.add(p7);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(3,1));
        sidePanel.add(btnLPf);
        sidePanel.add(btnLC);
        sidePanel.add(btnLogOut);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_pTitle,BorderLayout.NORTH);
            lbl_pTitle.setFont(myFont);
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public lecturerProfile(String firstName, String lastName, String gender, String contactNo, String email, String ic, String lecturerID, String position, String schoolEmail, String department, String salary) {
        lbl_pTitle = new JLabel("Profile");
        btnLPf = new JButton("Profile");
        btnLC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lblFN = new JLabel("First Name :");
        lblLN = new JLabel("Last Name :");
        lblGender = new JLabel("Gender :");
        lblConNo = new JLabel("Contact No :");
        lblEmail = new JLabel("Email :");
        lblIC= new JLabel("IC :");
        lblLID = new JLabel("Lecturer ID :");
        lblPosition = new JLabel("Position :");
        lblSchEmail = new JLabel("School Email :");
        lblDepart = new JLabel("Department :");
        lblSalary = new JLabel("Salary :");
        tfFN =new JTextField(15);
            tfFN.setEditable(false);
        tfLN =new JTextField(16);
            tfLN.setEditable(false);
        tfConNo =new JTextField(26);
            tfConNo.setEditable(false);
        tfEmail =new JTextField(42);
            tfEmail.setEditable(false);
        tfIC =new JTextField(44);
            tfIC.setEditable(false);
        tfLID =new JTextField(18);
            tfLID.setEditable(false);
        tfPosition =new JTextField(14);
            tfPosition.setEditable(false);
        tfSchEmail =new JTextField(38);
            tfSchEmail.setEditable(false);
        tfDepart =new JTextField(19);
            tfDepart.setEditable(false);
        tfSalary =new JTextField(14);
            tfSalary.setEditable(false);
        tfGender =new JTextField(14);
            tfGender.setEditable(false);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        btnLPf.addActionListener(this);
        btnLC.addActionListener(this);
        btnLogOut.addActionListener(this);
        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p1.add(lblFN);
        p1.add(tfFN);
        p1.add(lblLN);
        p1.add(tfLN);
        p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p2.add(lblGender);
        p2.add(tfGender);
        p2.add(lblConNo);
        p2.add(tfConNo);
        p3 = new JPanel();
        p3.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p3.add(lblEmail);
        p3.add(tfEmail);
        p4 = new JPanel();
        p4.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p4.add(lblIC);
        p4.add(tfIC);
        p5 = new JPanel();
        p5.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p5.add(lblLID);
        p5.add(tfLID);
        p5.add(lblPosition);
        p5.add(tfPosition);
        p6 = new JPanel();
        p6.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p6.add(lblSchEmail);
        p6.add(tfSchEmail);
        p7 = new JPanel();
        p7.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p7.add(lblDepart);
        p7.add(tfDepart);
        p7.add(lblSalary);
        p7.add(tfSalary);
        pAll = new JPanel();
        pAll.setLayout(new GridLayout(7,1));
        pAll.add(p1);
        pAll.add(p2);
        pAll.add(p3);
        pAll.add(p4);
        pAll.add(p5);
        pAll.add(p6);
        pAll.add(p7);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(3,1));
        sidePanel.add(btnLPf);
        sidePanel.add(btnLC);
        sidePanel.add(btnLogOut);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_pTitle,BorderLayout.NORTH);
            lbl_pTitle.setFont(myFont);
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);

        tfFN.setText(firstName);
        tfLN.setText(lastName);
        tfGender.setText(gender);
        tfConNo.setText(contactNo);
        tfEmail.setText(email);
        tfIC.setText(ic);
        tfLID.setText(lecturerID);
        tfPosition.setText(position);
        tfSchEmail.setText(schoolEmail);
        tfDepart.setText(department);
        tfSalary.setText(salary);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnLPf){
            JOptionPane.showMessageDialog(null,"You already in the Lecturer Profile page.");
        }
        if(e.getSource()==btnLC){
            String ic = tfIC.getText();
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT c.LecturerID FROM Course c,Lecturer l,userprofile p WHERE p.IC = l.IC AND l.LecturerID = c.LecturerID AND p.IC=?");
                stmt.setString(1, ic);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String id = rs.getString("LecturerID");

                    lecturerCourse p1 = new lecturerCourse(id);
                    p1.setTitle("Lecturer Course");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            lecturerLogin p4 = new lecturerLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
    }
}


