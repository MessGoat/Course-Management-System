package AssignmentJava2;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class studentFeedBack extends JFrame implements ActionListener{
    private JPanel sidePanel,mainPanel,fp,f1P,f2P,f3P;
    private JButton btnPf,btnBill,btnC,btnLogOut,btnSubmit;
    private JLabel lbl_fTitle,lblRate,lblCDate,lblC;
    private JTextArea taC;
    private JTextField tfRate;
    private String courseID,studentID;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        studentFeedBack frame = new studentFeedBack();
        frame.setTitle("Profile");
        frame.setSize(600,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
        
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
        
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }

    public studentFeedBack(){
        lbl_fTitle = new JLabel("FeedBack");
        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lblRate = new JLabel("Rate (1-10):");
        lblCDate = new JLabel("Comment Date (yyyy-mm-dd):");
        lblC = new JLabel("Comment :");
        tfRate = new JTextField(10);
        taC = new JTextArea(5,20);
        btnSubmit = new JButton("Submit");
         btnSubmit.addActionListener(this);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);
        fp = new JPanel();
        fp.setLayout(new FlowLayout(FlowLayout.LEFT));
        fp.add(lbl_fTitle);
            lbl_fTitle.setFont(myFont);
        f1P = new JPanel();
        f1P.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        f1P.add(lblRate);
        f1P.add(tfRate);
        f1P.add(lblCDate);
        f2P = new JPanel();
        f2P.setLayout(new BorderLayout());
        f2P.add(lblC,BorderLayout.NORTH);
        f2P.add(taC);
            taC.setBorder(new LineBorder(Color.gray,5));
        f3P = new JPanel();
        f3P.setLayout(new BorderLayout());
        f3P.add(f1P,BorderLayout.NORTH);
        f3P.add(f2P);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(fp,BorderLayout.NORTH);
        mainPanel.add(f3P);
        mainPanel.add(btnSubmit,BorderLayout.SOUTH);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnPf){
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM userprofile u,student s,studentcourse c WHERE u.IC=s.IC AND s.StudentID=c.StudentID AND c.StudentID=?");
                stmt.setString(1, studentID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String studentID = rs.getString("StudentID");
                    String intake = rs.getString("SemIntake");
                    String club = rs.getString("Club");
                    double scholarship = rs.getDouble("Scholarship");
                    String register = rs.getString("ResgistrationDate");
                    String address = rs.getString("Address");

                    studentProfile p1 = new studentProfile(firstName, lastName, gender, contactNo, email, ic, address, register, studentID, intake, club,scholarship);
                    p1.setTitle("Student Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnC){
            try{
                Connect_DB();
                studentCourse p1 = new studentCourse(studentID);
                p1.setTitle("Student Course");
                p1.setVisible(true);
                p1.setSize(800,350);
                p1.setLocationRelativeTo(null);
                dispose();
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnBill){
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Bill b,Student s,StudentCourse c WHERE b.StudentID = s.StudentID AND s.StudentID=c.StudentID AND c.StudentID=?");
                stmt.setString(1,studentID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String Invoice = rs.getString("Invoice");
                    double over = rs.getDouble("OverheadBill");
                    double paid = rs.getDouble("PaidBill");

                    studentBill p1 = new studentBill(studentID);
                    p1.setTitle("Student Bill");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            studentLogin p4 = new studentLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
        if(e.getSource()==btnSubmit){
            if(tfRate.getText().isEmpty() || taC.getText().isEmpty()){
                JOptionPane.showMessageDialog(this, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
                tfRate.setText("");
                taC.setText("");
            }else{
                int rate = Integer.parseInt(tfRate.getText());
                String comment = taC.getText();
                try{
                    if(rate>10 || rate<0){
                        JOptionPane.showMessageDialog(this,"Please enter rate between 0 - 10.");
                        return;
                    }
                    Connect_DB();
                        
                    PreparedStatement stmt = conn.prepareStatement("INSERT INTO Feedback (Comment,Rating,StudentID,CourseID) VALUES (?,?,?,?)");
                    
                    stmt.setString(1, comment);
                    stmt.setInt(2, rate);
                    stmt.setString(3, studentID);
                    stmt.setString(4, courseID);
                    stmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Feedback Submitted for "+courseID);

                    saveIntoFile();

                    tfRate.setText("");
                    taC.setText("");

                    conn.close();
                }catch(Exception ex1){
                    ex1.printStackTrace();
                }
            }
        }
    }

    public studentFeedBack(String courseID,String studentID){
        this.courseID=courseID;
        this.studentID=studentID;

        lbl_fTitle = new JLabel("FeedBack");
        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lblRate = new JLabel("Rate (1-10):");
        lblCDate = new JLabel("");
        lblC = new JLabel("Comment :");
        tfRate = new JTextField(10);
        taC = new JTextArea(5,20);
        btnSubmit = new JButton("Submit");
         btnSubmit.addActionListener(this);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);
        fp = new JPanel();
        fp.setLayout(new FlowLayout(FlowLayout.LEFT));
        fp.add(lbl_fTitle);
            lbl_fTitle.setFont(myFont);
        f1P = new JPanel();
        f1P.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        f1P.add(lblRate);
        f1P.add(tfRate);
        f1P.add(lblCDate);
        f2P = new JPanel();
        f2P.setLayout(new BorderLayout());
        f2P.add(lblC,BorderLayout.NORTH);
        f2P.add(taC);
            taC.setBorder(new LineBorder(Color.gray,5));
        f3P = new JPanel();
        f3P.setLayout(new BorderLayout());
        f3P.add(f1P,BorderLayout.NORTH);
        f3P.add(f2P);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(fp,BorderLayout.NORTH);
        mainPanel.add(f3P);
        mainPanel.add(btnSubmit,BorderLayout.SOUTH);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    private void saveIntoFile(){
        int rate = Integer.parseInt(tfRate.getText());
        String comment = taC.getText();
        String filePath = "feedback.txt";
        try {
            Connect_DB();
            PreparedStatement timestampStmt = conn.prepareStatement("SELECT CURRENT_TIMESTAMP()");
            ResultSet rsTimestamp = timestampStmt.executeQuery();
            rsTimestamp.next();
            Timestamp timestamp = rsTimestamp.getTimestamp(1);
    
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String formattedTimestamp = dateFormat.format(timestamp);
    
            BufferedWriter w1 = new BufferedWriter(new FileWriter(filePath, true));
            w1.write("StudentID: " + studentID + "\nCourseID: " + courseID + "\nRate: " + rate + "\nDate: " + formattedTimestamp + "\nComment: " + comment);
            w1.newLine();
            w1.newLine();
            w1.close();
            System.out.println("Feedback information has been successfully saved into file 'feedback.txt'.");
            
            conn.close();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

}


