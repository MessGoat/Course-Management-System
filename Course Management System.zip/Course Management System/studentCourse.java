package AssignmentJava2;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.LineBorder;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.event.*; 

//This is for Student Course 

public class studentCourse extends JFrame implements ActionListener{
    private JPanel sidePanel,mainPanel,cp1,cp1_2,cp1_3,cp1_4,cp1_5;
    private JButton btnPf,btnBill,btnC,btnLogOut,btnFeedB,btnGrade,btnSelection;
    private JLabel lbl_cTitle,lblCID,lblCName,lblCredit,lblBatch,lblSSem,lblStartSem,lblEndSem,lblYear,lblsid;
    private JTextField tfCID,tfCName,tfCredit,tfBatch,tfSSem,tfStartSem,tfEndSem,tfYear;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        studentCourse frame = new studentCourse();
        frame.setTitle("Course");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    //Connect Database Method
    public static void Connect_DB(){
        try{
            //1. Load Driver
            Class.forName(DRIVER);
        
            //2. Establish the connection
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
        
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }

    public studentCourse(){
        lbl_cTitle = new JLabel("Course");
        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");

        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        

        lblCID = new JLabel("CourseID :");
        lblCName = new JLabel("CourseName :");
        lblCredit = new JLabel("CreditHour");
        lblBatch = new JLabel("Batch :");
        lblSSem = new JLabel("Student Semester :");
        lblStartSem = new JLabel("Start Semester :");
        lblEndSem = new JLabel("End Semester :");
        lblYear = new JLabel("Year :");

        tfCID = new JTextField(14);     
        tfCName = new JTextField(14); 
        tfCredit = new JTextField(5); 
        tfBatch = new JTextField(5); 
        tfSSem = new JTextField(8); 
        tfStartSem = new JTextField(8); 
        tfEndSem = new JTextField(8); 
        tfYear = new JTextField(8);

        btnFeedB = new JButton("FeedBack");
        btnGrade = new JButton("Grade");
        btnSelection = new JButton("Selection");

        btnFeedB.addActionListener(this);
        btnGrade.addActionListener(this);
        btnSelection.addActionListener(this);

        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);

        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);

        cp1 = new JPanel();
        cp1.setLayout(new GridLayout(2,4));
        cp1.add(lblCID);
        cp1.add(tfCID);
            tfCID.setEditable(false);
        cp1.add(lblCredit);
        cp1.add(tfCredit);
            tfCredit.setEditable(false);
        cp1.add(lblCName);
        cp1.add(tfCName);
            tfCName.setEditable(false);
        cp1.add(lblBatch);
        cp1.add(tfBatch);  
            tfBatch.setEditable(false);
        
        cp1_2 = new JPanel();
        cp1_2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        cp1_2.add(lblSSem);
        cp1_2.add(tfSSem);
            tfSSem.setEditable(false);
        cp1_2.add(lblStartSem);
        cp1_2.add(tfStartSem);
            tfStartSem.setEditable(false);
        cp1_2.add(lblEndSem);
        cp1_2.add(tfEndSem);
            tfEndSem.setEditable(false);
        cp1_2.add(lblYear);
        cp1_2.add(tfYear);
            tfYear.setEditable(false);

        cp1_3 = new JPanel();
        cp1_3.setLayout(new FlowLayout(FlowLayout.RIGHT,10,0));
        cp1_3.add(btnFeedB);
        cp1_3.add(btnGrade);

        cp1_4 = new JPanel();
        cp1_4.setLayout(new GridLayout(3,1));
        cp1_4.setBorder(new LineBorder(Color.gray,5));
        cp1_4.add(cp1);
        cp1_4.add(cp1_2);
        cp1_4.add(cp1_3);

        cp1_5 = new JPanel();
        cp1_5.setLayout(new FlowLayout(FlowLayout.RIGHT));
        cp1_5.add(btnSelection);

        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_cTitle,BorderLayout.NORTH);
            lbl_cTitle.setFont(myFont);
        mainPanel.add(cp1_4);
        mainPanel.add(cp1_5,BorderLayout.SOUTH);

        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnPf){
            String id = lblsid.getText();

            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM userprofile u,student s,studentcourse c WHERE u.IC=s.IC AND s.StudentID=c.StudentID AND c.StudentID=?");
                stmt.setString(1, id);

                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    //Extract the lecturer information to other class
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String studentID = rs.getString("StudentID");
                    String intake = rs.getString("SemIntake");
                    String club = rs.getString("Club");
                    double scholarship = rs.getDouble("Scholarship");
                    String register = rs.getString("ResgistrationDate");
                    String address = rs.getString("Address");

                    studentProfile p1 = new studentProfile(firstName, lastName, gender, contactNo, email, ic, address, register, studentID, intake, club,scholarship);
                    p1.setTitle("Student Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }

                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnC){
            JOptionPane.showMessageDialog(null,"You already in the Student Course page.");
        }
        if(e.getSource()==btnBill){
            String id = lblsid.getText();
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Bill b,Student s,StudentCourse c WHERE b.StudentID = s.StudentID AND s.StudentID=c.StudentID AND c.StudentID=?");
                stmt.setString(1,id);
                ResultSet rs = stmt.executeQuery();

                if(rs.next()){
                    String Invoice = rs.getString("Invoice");
                    double over = rs.getDouble("OverheadBill");
                    double paid = rs.getDouble("PaidBill");

                    studentBill p1 = new studentBill(id);
                    p1.setTitle("Student Bill");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            studentLogin p4 = new studentLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
        if(e.getSource()==btnSelection){
            String courseID = tfCID.getText();
            String studentID = lblsid.getText();
            try{
                Connect_DB();

                studentCourseSelection p1 = new studentCourseSelection(courseID,studentID);
                p1.setTitle("Course Selection");
                p1.setVisible(true);
                p1.setSize(800,350);
                p1.setLocationRelativeTo(null);
                dispose();

                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
    }

    public studentCourse(String StudentID) {
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(0, 1));
        try {
            Connect_DB();

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Course c,Student s,StudentCourse t,Semester b WHERE c.CourseID=t.CourseID AND t.StudentID=s.StudentID AND c.Batch=b.Batch AND t.Attendance IS NULL AND t.StudentID=?");
            stmt.setString(1, StudentID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String courseID = rs.getString("CourseID");
                String courseName = rs.getString("CourseName");
                int creditHour = rs.getInt("CreditHours");
                String batch = rs.getString("Batch");
                String intake = rs.getString("SemIntake");
                String start = rs.getString("StartSem");
                String end = rs.getString("EndSem");
                String year = rs.getString("Year");
                String studentID = rs.getString("StudentID");
                JPanel coursePanel = createCoursePanel(courseID, courseName, creditHour,batch,intake,start,end,year,studentID);
                mainPanel.add(coursePanel);
            }
            cp1_5 = new JPanel();
            cp1_5.setLayout(new FlowLayout(FlowLayout.RIGHT));
            cp1_5.add(btnSelection);
            mainPanel.add(cp1_5,BorderLayout.SOUTH);

            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        add(new JScrollPane(mainPanel)); 
    }

    public JPanel createCoursePanel(String courseID,String courseName,int creditHour,String batch,String intake,String start,String end,String year,String StudentID){
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        lblsid = new JLabel(StudentID);
        lbl_cTitle = new JLabel("Course :"+courseID+" : "+courseName);
        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        lblCID = new JLabel("CourseID :");
        lblCName = new JLabel("CourseName :");
        lblCredit = new JLabel("CreditHour");
        lblBatch = new JLabel("Batch :");
        lblSSem = new JLabel("Student Semester :");
        lblStartSem = new JLabel("Start Semester :");
        lblEndSem = new JLabel("End Semester :");
        lblYear = new JLabel("Year :");
        tfCID = new JTextField(10);     
        tfCName = new JTextField(10); 
        tfCredit = new JTextField(10); 
        tfBatch = new JTextField(10); 
        tfSSem = new JTextField(12); 
        tfStartSem = new JTextField(6); 
        tfEndSem = new JTextField(6); 
        tfYear = new JTextField(4);
        btnFeedB = new JButton("FeedBack");
        btnGrade = new JButton("Grade");
        btnSelection = new JButton("Selection");
        btnFeedB.addActionListener(this);
        btnGrade.addActionListener(this);
        btnSelection.addActionListener(this);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        cp1 = new JPanel();
        cp1.setLayout(new GridLayout(2,4));
        cp1.add(lblCID);
        cp1.add(tfCID);
            tfCID.setEditable(false);
        cp1.add(lblCredit);
        cp1.add(tfCredit);
            tfCredit.setEditable(false);
        cp1.add(lblCName);
        cp1.add(tfCName);
            tfCName.setEditable(false);
        cp1.add(lblBatch);
        cp1.add(tfBatch);  
            tfBatch.setEditable(false);
        cp1_2 = new JPanel();
        cp1_2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        cp1_2.add(lblSSem);
        cp1_2.add(tfSSem);
            tfSSem.setEditable(false);
        cp1_2.add(lblStartSem);
        cp1_2.add(tfStartSem);
            tfStartSem.setEditable(false);
        cp1_2.add(lblEndSem);
        cp1_2.add(tfEndSem);
            tfEndSem.setEditable(false);
        cp1_2.add(lblYear);
        cp1_2.add(tfYear);
            tfYear.setEditable(false);
        cp1_3 = new JPanel();
        cp1_3.setLayout(new FlowLayout(FlowLayout.RIGHT,10,0));
        cp1_3.add(btnFeedB);
        cp1_3.add(btnGrade);
        cp1_4 = new JPanel();
        cp1_4.setLayout(new GridLayout(3,1));
        cp1_4.setBorder(new LineBorder(Color.gray,5));
        cp1_4.add(cp1);
        cp1_4.add(cp1_2);
        cp1_4.add(cp1_3);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_cTitle,BorderLayout.NORTH);
            lbl_cTitle.setFont(myFont);
        mainPanel.add(cp1_4);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);

        tfCID.setText(courseID);
        tfCName.setText(courseName);
        tfCredit.setText(""+creditHour);
        tfBatch.setText(batch);
        tfSSem.setText(intake);
        tfStartSem.setText(start);
        tfEndSem.setText(end);
        tfYear.setText(year);

        btnFeedB.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            try{
                Connect_DB();

                studentFeedBack p1 = new studentFeedBack(courseID,StudentID);
                p1.setTitle("Feedback");
                p1.setVisible(true);
                p1.setSize(800,350);
                p1.setLocationRelativeTo(null);
                dispose();

                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }});

        btnGrade.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Grade g,Course c WHERE g.CourseID=c.CourseID AND g.CourseID=? AND g.StudentID=?");
                stmt.setString(1, courseID);
                stmt.setString(2, StudentID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    double amark = rs.getDouble("AssessmentMarks");
                    double fmark = rs.getDouble("FinalMarks");
                    String courseName = rs.getString("courseName");
                    
                    studentGrade p1 = new studentGrade(courseID,courseName,StudentID,amark,fmark);
                    p1.setTitle("Student Grade");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }});
        return mainPanel;
    }
}

