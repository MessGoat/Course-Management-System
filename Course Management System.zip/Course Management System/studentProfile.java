package AssignmentJava2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class studentProfile extends JFrame implements ActionListener{
    private JPanel sidePanel,mainPanel,p1,p2,p3,p4,p5,p6,p7,pAll;
    private JButton btnPf,btnBill,btnC,btnLogOut;
    private JLabel lbl_pTitle,lblFN,lblLN,lblGender,lblConNo,lblEmail,lblIC,lblSID,lblSemIntake,lblClub,lblRegDate,lblScShip,lblAdd;
    private JTextField tfFN,tfLN,tfConNo,tfEmail,tfIC,tfSID,tfSemIntake,tfClub,tfRegDate,tfScShip,tfAdd,tfGender;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        studentProfile frame = new studentProfile();
        frame.setTitle("Student Profile");
        frame.setSize(600,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
    
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
    
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }

    public studentProfile(){
        lbl_pTitle = new JLabel("Profile");
        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lblFN = new JLabel("First Name :");
        lblLN = new JLabel("Last Name :");
        lblGender = new JLabel("Gender :");
        lblConNo = new JLabel("Contact No :");
        lblEmail = new JLabel("Email :");
        lblIC= new JLabel("IC :");
        lblSID = new JLabel("Student ID :");
        lblSemIntake = new JLabel("Semester Intake :");
        lblClub = new JLabel("Club :");
        lblRegDate = new JLabel("Registered Date :");
        lblScShip = new JLabel("Scholar Ship :");
        lblAdd = new JLabel("Address :");
        tfFN =new JTextField(15);
            tfFN.setEditable(false);
        tfLN =new JTextField(16);
            tfLN.setEditable(false);
        tfConNo =new JTextField(26);
            tfConNo.setEditable(false);
        tfEmail =new JTextField(42);
            tfEmail.setEditable(false);
        tfIC =new JTextField(44);
            tfIC.setEditable(false);
        tfSID =new JTextField(14);
            tfSID.setEditable(false);
        tfSemIntake =new JTextField(14);
            tfSemIntake.setEditable(false);
        tfClub =new JTextField(14);
            tfClub.setEditable(false);
        tfRegDate =new JTextField(17);
            tfRegDate.setEditable(false);
        tfScShip =new JTextField(14);
            tfScShip.setEditable(false);
        tfAdd =new JTextField(17);
            tfAdd.setEditable(false);
        tfGender =new JTextField(14);
            tfGender.setEditable(false);;
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p1.add(lblFN);
        p1.add(tfFN);
        p1.add(lblLN);
        p1.add(tfLN);
        p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p2.add(lblGender);
        p2.add(tfGender);
        p2.add(lblConNo);
        p2.add(tfConNo);
        p3 = new JPanel();
        p3.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p3.add(lblEmail);
        p3.add(tfEmail);
        p4 = new JPanel();
        p4.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p4.add(lblIC);
        p4.add(tfIC);
        p5 = new JPanel();
        p5.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p5.add(lblSID);
        p5.add(tfSID);
        p5.add(lblSemIntake);
        p5.add(tfSemIntake);
        p6 = new JPanel();
        p6.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p6.add(lblClub);
        p6.add(tfClub);
        p6.add(lblRegDate);
        p6.add(tfRegDate);
        p7 = new JPanel();
        p7.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p7.add(lblScShip);
        p7.add(tfScShip);
        p7.add(lblAdd);
        p7.add(tfAdd);
        pAll = new JPanel();
        pAll.setLayout(new GridLayout(7,1));
        pAll.add(p1);
        pAll.add(p2);
        pAll.add(p3);
        pAll.add(p4);
        pAll.add(p5);
        pAll.add(p6);
        pAll.add(p7);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_pTitle,BorderLayout.NORTH);
            lbl_pTitle.setFont(myFont);
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnPf){
            JOptionPane.showMessageDialog(null,"You already in the Student Profile page.");
        }
        if(e.getSource()==btnBill){
            String id = tfSID.getText();
            try{
                Connect_DB();
                studentBill p1 = new studentBill(id);
                p1.setTitle("Student Bill");
                p1.setVisible(true);
                p1.setSize(800,350);
                p1.setLocationRelativeTo(null);
                dispose();
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnC){
            String id = tfSID.getText();
            try{
                Connect_DB();
                studentCourse p1 = new studentCourse(id);
                p1.setTitle("Student Course");
                p1.setVisible(true);
                p1.setSize(800,350);
                p1.setLocationRelativeTo(null);
                dispose();
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            studentLogin p4 = new studentLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
    }

    public studentProfile(String firstName, String lastName, String gender, String contactNo, String email, String ic, String address, String register, String studentID, String intake, String club, double scholarship){
        lbl_pTitle = new JLabel("Profile");
        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lblFN = new JLabel("First Name :");
        lblLN = new JLabel("Last Name :");
        lblGender = new JLabel("Gender :");
        lblConNo = new JLabel("Contact No :");
        lblEmail = new JLabel("Email :");
        lblIC= new JLabel("IC :");
        lblSID = new JLabel("Student ID :");
        lblSemIntake = new JLabel("Semester Intake :");
        lblClub = new JLabel("Club :");
        lblRegDate = new JLabel("Registered Date :");
        lblScShip = new JLabel("Scholar Ship :");
        lblAdd = new JLabel("Address :");
        tfFN =new JTextField(15);
            tfFN.setEditable(false);
        tfLN =new JTextField(16);
            tfLN.setEditable(false);
        tfConNo =new JTextField(26);
            tfConNo.setEditable(false);
        tfEmail =new JTextField(42);
            tfEmail.setEditable(false);
        tfIC =new JTextField(17);
            tfIC.setEditable(false);
        tfSID =new JTextField(14);
            tfSID.setEditable(false);
        tfSemIntake =new JTextField(14);
            tfSemIntake.setEditable(false);
        tfClub =new JTextField(14);
            tfClub.setEditable(false);
        tfRegDate =new JTextField(17);
            tfRegDate.setEditable(false);
        tfScShip =new JTextField(14);
            tfScShip.setEditable(false);
        tfAdd =new JTextField(42);
            tfAdd.setEditable(false);
        tfGender =new JTextField(14);
            tfGender.setEditable(false);;
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p1.add(lblFN);
        p1.add(tfFN);
        p1.add(lblLN);
        p1.add(tfLN);
        p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p2.add(lblGender);
        p2.add(tfGender);
        p2.add(lblConNo);
        p2.add(tfConNo);
        p3 = new JPanel();
        p3.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p3.add(lblEmail);
        p3.add(tfEmail);
        p4 = new JPanel();
        p4.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p4.add(lblAdd);
        p4.add(tfAdd);
        p5 = new JPanel();
        p5.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p5.add(lblSID);
        p5.add(tfSID);
        p5.add(lblSemIntake);
        p5.add(tfSemIntake);
        p6 = new JPanel();
        p6.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p6.add(lblClub);
        p6.add(tfClub);
        p6.add(lblRegDate);
        p6.add(tfRegDate);
        p7 = new JPanel();
        p7.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p7.add(lblScShip);
        p7.add(tfScShip);
        p7.add(lblIC);
        p7.add(tfIC);
        pAll = new JPanel();
        pAll.setLayout(new GridLayout(7,1));
        pAll.add(p1);
        pAll.add(p2);
        pAll.add(p3);
        pAll.add(p4);
        pAll.add(p5);
        pAll.add(p6);
        pAll.add(p7);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_pTitle,BorderLayout.NORTH);
            lbl_pTitle.setFont(myFont);
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);

        tfFN.setText(firstName);
        tfLN.setText(lastName);
        tfConNo.setText(contactNo);
        tfEmail.setText(email);
        tfIC.setText(ic);
        tfSID.setText(studentID);
        tfSemIntake.setText(intake);
        tfClub.setText(club);
        tfScShip.setText(""+scholarship);
        tfAdd.setText(address);
        tfGender.setText(gender);
        tfRegDate.setText(register);
    }
}

