package AssignmentJava2;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class lecturerGrading extends JFrame implements ActionListener {
    private JPanel sidePanel,mainPanel,lp1,lp2,lp3,lp4,lp5,lp6,lp7,pAll,pBtn;
    private JButton btnLPf,btnLC,btnLogOut,btnAdd;
    private JLabel lbl_gTitle,lblSID,lblSaMarks,lblSfMarks,lblStMarks,lblEnter,lbl_dSID,lbl_dSaMarks,lbl_dSfMarks,lbl_Grade,lbl_course;
    private JTextField tfSID,tfSaMarks,tfSfMarks,tfStMarks,tfE_SID,tfESaMarks,tfESfMarks,tf_Grade;
    private String courseID;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        lecturerGrading frame = new lecturerGrading();
        frame.setTitle("Grading");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }
    
    public lecturerGrading(){
        lbl_gTitle = new JLabel("Grading");
        btnLPf = new JButton("Profile");
        btnLC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        btnLPf.addActionListener(this);
        btnLC.addActionListener(this);
        btnLogOut.addActionListener(this);
        lblEnter = new JLabel("Enter :");
        lblSID = new JLabel("Student ID :");
        lblSaMarks = new JLabel("Assessment Marks :");
        lblSfMarks = new JLabel("Final Marks :");
        lblStMarks = new JLabel("Total Marks :");
        lbl_dSID = new JLabel("Student ID :");
        
        lbl_dSaMarks = new JLabel("Assessment Marks :");
        lbl_dSfMarks = new JLabel("Final Marks :");
        lbl_Grade =  new JLabel("Grade :");
        tf_Grade = new JTextField(10);
        tf_Grade.setEditable(false);
        tfSID = new JTextField(10);
            tfSID.setEditable(false);
        tfSaMarks = new JTextField(10);
            tfSaMarks.setEditable(false);
        tfSfMarks = new JTextField(10);
            tfSfMarks.setEditable(false);
        tfStMarks = new JTextField(10);
            tfStMarks.setEditable(false);
        tfE_SID = new JTextField(20);
        tfESaMarks = new JTextField(10);
        tfESfMarks = new JTextField(10);
        btnAdd = new JButton("Change");
        btnAdd.addActionListener(this);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(3,1));
        sidePanel.add(btnLPf);
        sidePanel.add(btnLC);
        sidePanel.add(btnLogOut);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        lp1 = new JPanel();
        lp1.setLayout(new FlowLayout(FlowLayout.LEFT,15,0));
        lp1.add(lbl_dSID);
        lp1.add(tfSID);
        lp1.add(lbl_dSaMarks);
        lp1.add(tfSaMarks);
        lp1.add(lbl_dSfMarks);
        lp1.add(tfSfMarks);
        lp1.add(lblStMarks);
        lp1.add(tfStMarks);
        lp1.add(lbl_Grade);
        lp1.add(tf_Grade);
        lp2 = new JPanel();
        lp2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        lp2.add(lblEnter);
        lp3 = new JPanel();
        lp3.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        lp3.add(lblSID);
        lp3.add(tfE_SID);
        lp4 = new JPanel();
        lp4.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        lp4.add(lblSaMarks);
        lp4.add(tfESaMarks);
        lp5 = new JPanel(); 
        lp5.setLayout(new GridLayout(2,1));
        lp5.add(lp3);
        lp5.add(lp4);
        pBtn = new JPanel();
        pBtn.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pBtn.add(btnAdd);
        lp6 = new JPanel();
        lp6.setLayout(new BorderLayout());
        lp6.add(lp2,BorderLayout.NORTH);
            lblEnter.setFont(myFont);
        lp6.add(lp5); 
        lp7 = new JPanel();
        lp7.setLayout(new BorderLayout());
        lp7.setBorder(new LineBorder(Color.gray,5));
        lp7.add(lp6);
        lp7.add(pBtn,BorderLayout.SOUTH);
        pAll = new JPanel();
        pAll.setLayout(new GridLayout(2,1));
        pAll.add(lp1);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_gTitle,BorderLayout.NORTH);
            lbl_gTitle.setFont(myFont);
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnLPf){
            try{
                Connect_DB();
                PreparedStatement stmt = conn.prepareStatement("SELECT u.Fname,u.Lname,u.ContactNo,u.Email,u.Address,u.IC,u.Gender,u.ResgistrationDate,l.LecturerID,l.Position,l.SchoolEmail,l.Department,l.Salary FROM userprofile u,lecturer l,course c WHERE u.IC = l.IC AND l.LecturerID = c.LecturerID AND CourseID =?");
                stmt.setString(1,courseID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String lecturerID = rs.getString("LecturerID");
                    String position = rs.getString("Position");
                    String schoolEmail = rs.getString("SchoolEmail");
                    String department = rs.getString("Department");
                    String salary = rs.getString("Salary");

                    lecturerProfile p1 = new lecturerProfile(firstName, lastName, gender, contactNo, email, ic, lecturerID, position, schoolEmail, department, salary);
                    p1.setTitle("Lecturer Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLC){
            try{
                Connect_DB();
                PreparedStatement stmt = conn.prepareStatement("SELECT c.CourseID, c.CourseName, c.CreditHours, c.LecturerID FROM Course c,Lecturer l,userprofile p WHERE p.IC = l.IC AND l.LecturerID = c.LecturerID AND c.CourseID=?");
                stmt.setString(1, courseID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String courseID = rs.getString("CourseID");
                    String courseName = rs.getString("CourseName");
                    int creditHour = rs.getInt("CreditHours");
                    String id = rs.getString("LecturerID");

                    lecturerCourse p1 = new lecturerCourse(id);
                    p1.setTitle("Lecturer Course");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            lecturerLogin p4 = new lecturerLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
        if(e.getSource()==btnAdd){
            try{
                String id = tfE_SID.getText();
                double assmark = 0.0;
                double finmark = 0.0;
                double mark =0.0;
                String grade ="";
                
                if(id.isEmpty() || tfESaMarks.getText().isEmpty() || tfESfMarks.getText().isEmpty()){
                    JOptionPane.showMessageDialog(null,"Please enter both studentID and mark.");
                    return;
                }else if(!id.equals(tfSID.getText())){
                    JOptionPane.showMessageDialog(this, "Invalid Student ID.");
                    return;
                }else{
                    assmark = Double.parseDouble(tfESaMarks.getText());
                    finmark = Double.parseDouble(tfESfMarks.getText());
                    mark = assmark+finmark;
                }

                if(assmark <0 || assmark>60 || finmark <0 || finmark >40){
                    JOptionPane.showMessageDialog(this,"Please enter marks within the given range.");
                    return;
                }else if(mark <= 100 && mark >80){
                    grade = "A";
                    tf_Grade.setText(grade);
                    JOptionPane.showMessageDialog(this, "Student "+id +" marks has been changed.");
                }else if(mark <=80 && mark >70){
                    grade = "B";
                    tf_Grade.setText(grade);
                    JOptionPane.showMessageDialog(this, "Student "+id +" marks has been changed.");
                }else if(mark <=70 && mark >60){
                    grade = "C";
                    tf_Grade.setText(grade);
                    JOptionPane.showMessageDialog(this, "Student "+id +" marks has been changed.");
                }else if(mark <=60 && mark >50){
                    grade = "D";
                    tf_Grade.setText(grade);
                    JOptionPane.showMessageDialog(this, "Student "+id +" marks has been changed.");
                }else if(mark <=50 && mark >40){
                    grade = "E";
                    tf_Grade.setText(grade);
                    JOptionPane.showMessageDialog(this, "Student "+id +" marks has been changed.");
                }else if(mark <=40 && mark >=0){
                    grade = "F";
                    tf_Grade.setText(grade);
                    JOptionPane.showMessageDialog(this, "Student "+id +" marks has been changed.");
                }else{
                    JOptionPane.showMessageDialog(this,"Please enter marks between 0 - 100.");
                    return;
                }
                Connect_DB();
                PreparedStatement stmt = conn.prepareStatement("UPDATE Grade SET AssessmentMarks=?,FinalMarks=? WHERE StudentID=? AND CourseID=?");
                stmt.setDouble(1, assmark);
                stmt.setDouble(2, finmark);
                stmt.setString(3, id);
                stmt.setString(4, courseID);
                stmt.executeUpdate();

                tfSaMarks.setText(""+assmark);
                tfSfMarks.setText(""+finmark);

                tfStMarks.setText(""+mark);
                tf_Grade.setText(grade);
                tfESaMarks.setText("");
                tfESfMarks.setText("");
                tfE_SID.setText("");

                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
    }

    public lecturerGrading(String CourseID) {
        this.courseID=CourseID;
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(0, 1));
        try {
            Connect_DB();

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Grade WHERE CourseID=?");
            stmt.setString(1, CourseID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String courseID = rs.getString("CourseID");
                double amarks = rs.getDouble("AssessmentMarks");
                double fmarks = rs.getDouble("FinalMarks");
                String studentID = rs.getString("StudentID");

                JPanel gradePanel = createGradingPanel(courseID, amarks, fmarks,studentID);
                mainPanel.add(gradePanel);
            }
            pAll.add(lp7);
            
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        add(new JScrollPane(mainPanel)); // Add a JScrollPane to enable scrolling if needed
    }

    public JPanel createGradingPanel(String courseID,double amarks,double fmarks,String studentID){
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        lbl_gTitle = new JLabel("Grading : "+studentID);
        btnLPf = new JButton("Profile");
        btnLC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        btnLPf.addActionListener(this);
        btnLC.addActionListener(this);
        btnLogOut.addActionListener(this);
        lblEnter = new JLabel("Enter :");
        lblSID = new JLabel("Student ID :");
        lblSaMarks = new JLabel("Assessment Marks (0-60):");
        lblSfMarks = new JLabel("Final Marks (0-40):");
        lblStMarks = new JLabel("Total Marks :");
        lbl_dSID = new JLabel("Student ID :");
        
        lbl_dSaMarks = new JLabel("Assessment Marks (0-60):");
        lbl_dSfMarks = new JLabel("Final Marks (0-40):");
        lbl_Grade =  new JLabel("Grade :");
        tf_Grade = new JTextField(10);
        tf_Grade.setEditable(false);
        tfSID = new JTextField(10);
            tfSID.setEditable(false);
        tfSaMarks = new JTextField(10);
            tfSaMarks.setEditable(false);
        tfSfMarks = new JTextField(10);
            tfSfMarks.setEditable(false);
        tfStMarks = new JTextField(10);
            tfStMarks.setEditable(false);
        tfE_SID = new JTextField(20);
        tfESaMarks = new JTextField(10);
        tfESfMarks = new JTextField(10);
        btnAdd = new JButton("Change");
        btnAdd.addActionListener(this);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(3,1));
        sidePanel.add(btnLPf);
        sidePanel.add(btnLC);
        sidePanel.add(btnLogOut);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        lp1 = new JPanel();
        lp1.setLayout(new FlowLayout(FlowLayout.LEFT,15,0));
        lp1.add(lbl_dSID);
        lp1.add(tfSID);
        lp1.add(lbl_dSaMarks);
        lp1.add(tfSaMarks);
        lp1.add(lbl_dSfMarks);
        lp1.add(tfSfMarks);
        lp1.add(lblStMarks);
        lp1.add(tfStMarks);
        lp1.add(lbl_Grade);
        lp1.add(tf_Grade);
        lp2 = new JPanel();
        lp2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        lp2.add(lblEnter);
        lp3 = new JPanel();
        lp3.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        lp3.add(lblSID);
        lp3.add(tfE_SID);
        lp4 = new JPanel();
        lp4.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        lp4.add(lblSaMarks);
        lp4.add(tfESaMarks);

        lp4.add(lblSfMarks);
        lp4.add(tfESfMarks);

        lp5 = new JPanel(); 
        lp5.setLayout(new GridLayout(2,1));
        lp5.add(lp3);
        lp5.add(lp4);
        pBtn = new JPanel();
        pBtn.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pBtn.add(btnAdd);
        lp6 = new JPanel();
        lp6.setLayout(new BorderLayout());
        lp6.add(lp2,BorderLayout.NORTH);
            lblEnter.setFont(myFont);
        lp6.add(lp5); 
        lp7 = new JPanel();
        lp7.setLayout(new BorderLayout());
        lp7.setBorder(new LineBorder(Color.gray,5));
        lp7.add(lp6);
        lp7.add(pBtn,BorderLayout.SOUTH);
        pAll = new JPanel();
        pAll.setLayout(new GridLayout(2,1));
        pAll.add(lp1);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_gTitle,BorderLayout.NORTH);
            lbl_gTitle.setFont(myFont);
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);

        tfSID.setText(studentID);
        tfSaMarks.setText(""+amarks);
        tfSfMarks.setText(""+fmarks);

        double assessmark = Double.parseDouble(tfSaMarks.getText());
        double finalmark = Double.parseDouble(tfSfMarks.getText());

        double grading = assessmark+finalmark;

        tfStMarks.setText(""+grading);

        String grade ="";
        if(grading <= 100 && grading >80){
            grade = "A";
            tf_Grade.setText(grade);
        }else if(grading <=80 && grading >70){
            grade = "B";
            tf_Grade.setText(grade);
        }else if(grading <=70 && grading >60){
            grade = "C";
            tf_Grade.setText(grade);
        }else if(grading <=60 && grading >50){
            grade = "D";
            tf_Grade.setText(grade);
        }else if(grading <=50 && grading >60){
            grade = "E";
            tf_Grade.setText(grade);
        }else if(grading <=40 && grading >0){
            grade = "F";
            tf_Grade.setText(grade);
        }else{
            grade = "null";
            tf_Grade.setText(grade);
        }
        return mainPanel;
    }
}
