package AssignmentJava2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class studentGrade extends JFrame implements ActionListener{
    private JPanel sidePanel,mainPanel;
    private JButton btnPf,btnBill,btnC,btnLogOut;
    private JLabel lbl_gTitle,lbl_grade,lbl_amark,lbl_fmark,lbl_tmark,blank;
    private JTextField tf_grade,tf_amark,tf_fmark,tf_tmark;
    private String courseID,studentID;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        studentGrade frame = new studentGrade();
        frame.setTitle("Grade");
        frame.setSize(600,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
        
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
        
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }

    public studentGrade(){
        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lbl_gTitle = new JLabel("Grade");
        lbl_grade = new JLabel("Grade :");
        lbl_amark = new JLabel("Assessment Marks :");
        lbl_fmark = new JLabel("Final Marks :");
        lbl_tmark = new JLabel("Total Marks :");
        blank = new JLabel();
        tf_grade = new JTextField();
        tf_amark = new JTextField();
        tf_fmark = new JTextField();
        tf_tmark = new JTextField();
        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(5,2));
        mainPanel.add(lbl_gTitle);
        lbl_gTitle.setFont(myFont);
        mainPanel.add(blank);
        mainPanel.add(lbl_grade);
        mainPanel.add(tf_grade);
        tf_grade.setEditable(false);
        mainPanel.add(lbl_amark);
        mainPanel.add(tf_amark);
        tf_amark.setEditable(false);

        mainPanel.add(lbl_fmark);
        mainPanel.add(tf_fmark);
        tf_fmark.setEditable(false);

        mainPanel.add(lbl_tmark);
        mainPanel.add(tf_tmark);
        tf_tmark.setEditable(false);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnPf){
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM userprofile u,student s,studentcourse c WHERE u.IC=s.IC AND s.StudentID=c.StudentID AND c.StudentID=?");
                stmt.setString(1, studentID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String studentID = rs.getString("StudentID");
                    String intake = rs.getString("SemIntake");
                    String club = rs.getString("Club");
                    double scholarship = rs.getDouble("Scholarship");
                    String register = rs.getString("ResgistrationDate");
                    String address = rs.getString("Address");

                    studentProfile p1 = new studentProfile(firstName, lastName, gender, contactNo, email, ic, address, register, studentID, intake, club,scholarship);
                    p1.setTitle("Student Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnC){
            try{
                Connect_DB();
                studentCourse p1 = new studentCourse(studentID);
                p1.setTitle("Student Course");
                p1.setVisible(true);
                p1.setSize(800,350);
                p1.setLocationRelativeTo(null);
                dispose();
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnBill){
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Bill b,Student s,StudentCourse c WHERE b.StudentID = s.StudentID AND s.StudentID=c.StudentID AND c.StudentID=?");
                stmt.setString(1,studentID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String Invoice = rs.getString("Invoice");
                    double over = rs.getDouble("OverheadBill");
                    double paid = rs.getDouble("PaidBill");

                    studentBill p1 = new studentBill(studentID);
                    p1.setTitle("Student Bill");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            studentLogin p4 = new studentLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
    }

    public studentGrade(String courseID,String courseName,String studentID,double amark,double fmark){
        this.courseID=courseID;
        this.studentID=studentID;

        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lbl_gTitle = new JLabel(courseID+" : "+courseName);
        lbl_grade = new JLabel("Grade :");
        lbl_amark = new JLabel("Assessment Marks :");
        lbl_fmark = new JLabel("Final Marks :");
        lbl_tmark = new JLabel("Total Marks :");
        blank = new JLabel();
        tf_grade = new JTextField();
        tf_amark = new JTextField();
        tf_fmark = new JTextField();
        tf_tmark = new JTextField();
        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(5,2));
        mainPanel.add(lbl_gTitle);
        lbl_gTitle.setFont(myFont);
        mainPanel.add(blank);
        mainPanel.add(lbl_grade);
        mainPanel.add(tf_grade);
        tf_grade.setEditable(false);
        mainPanel.add(lbl_amark);
        mainPanel.add(tf_amark);
        tf_amark.setEditable(false);
        mainPanel.add(lbl_fmark);
        mainPanel.add(tf_fmark);
        tf_fmark.setEditable(false);
        mainPanel.add(lbl_tmark);
        mainPanel.add(tf_tmark);
        tf_tmark.setEditable(false);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);

        tf_amark.setText(""+amark);
        tf_fmark.setText(""+fmark);
        
        double mark = amark+fmark;
        tf_tmark.setText(""+mark);
        String grade = "";

        if(mark <= 100 && mark >80){
            grade = "A";
            tf_grade.setText(grade);
        }else if(mark <=80 && mark >70){
            grade = "B";
            tf_grade.setText(grade);
        }else if(mark <=70 && mark >60){
            grade = "C";
            tf_grade.setText(grade);
        }else if(mark <=60 && mark >50){
            grade = "D";
            tf_grade.setText(grade);
        }else if(mark <=50 && mark >40){
            grade = "E";
            tf_grade.setText(grade);
        }else if(mark <=40 && mark >0){
            grade = "F";
            tf_grade.setText(grade);
        }
    }
}

