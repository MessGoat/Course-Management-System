package AssignmentJava2;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class studentLogin extends JFrame implements ActionListener{
    private JPanel mainPanel,p1,pp1,p2,pp2,p4,pAll,pT;
    private JButton btnCancel,btnLogin;
    private JLabel lbl_Login,lblID,lblPass;
    private JPasswordField tfPass;
    private JTextField tfID;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        studentLogin frame = new studentLogin();
        frame.setTitle("Login");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
    
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
    
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }
    
    public studentLogin(){
        lbl_Login = new JLabel("LOGIN AS STUDENT");
        Font myFont = new Font("SansSerif ", Font.BOLD, 35);
        lblID = new JLabel("ID :");
        lblPass = new JLabel("Password :");
        tfID = new JTextField(20);
        tfPass = new JPasswordField(20);
        btnCancel = new JButton("Cancel");
        btnLogin = new JButton("Login");
        btnLogin.addActionListener(this);
        btnCancel.addActionListener(this);
        pp1 = new JPanel();
        pp1.setLayout(new GridLayout(1,2));
        pp1.add(lblID);
        pp1.add(tfID);
        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.CENTER,5,0));
        p1.add(pp1);
        pp2 = new JPanel();
        pp2.setLayout(new GridLayout(1,2));
        pp2.add(lblPass);
        pp2.add(tfPass);
        p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.CENTER,5,0));
        p2.add(pp2);
        p4 = new JPanel();
        p4.setLayout(new FlowLayout(FlowLayout.CENTER,5,0));
        p4.add(btnCancel);
        p4.add(btnLogin);
        pAll = new JPanel();
        pAll.setLayout(new GridLayout(5,1));
        pAll.add(p1);
        pAll.add(p2);
        pAll.add(p4);
        pT = new JPanel();
        pT.setLayout(new FlowLayout(FlowLayout.CENTER,5,0));
        pT.add(lbl_Login);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(pT,BorderLayout.NORTH);
            lbl_Login.setFont(myFont);
        mainPanel.add(pAll);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnLogin){
            String id = tfID.getText();
            String password = tfPass.getText();
            if(id.isEmpty() || password.isEmpty()){
                JOptionPane.showMessageDialog(null,"Please enter both ID and password");
                return;
            }
            try{
                Connect_DB();
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM userprofile,student WHERE StudentID =? AND password =?");
                stmt.setString(1,id);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String studentID = rs.getString("StudentID");
                    String intake = rs.getString("SemIntake");
                    String club = rs.getString("Club");
                    double scholarship = rs.getDouble("Scholarship");
                    String register = rs.getString("ResgistrationDate");
                    String address = rs.getString("Address");

                    JOptionPane.showMessageDialog(null, "Welcome to Course Management System "+studentID);
                    studentProfile p1 = new studentProfile(firstName, lastName, gender, contactNo, email, ic, address, register, studentID, intake, club,scholarship);
                    p1.setTitle("Student Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }else{
                    JOptionPane.showMessageDialog(null,"Invalid ID or password.", "Login Error", JOptionPane.ERROR_MESSAGE);
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnCancel){
            loginProfile p1 = new loginProfile();
            p1.setTitle("Login Profile");
            p1.setVisible(true);
            p1.setSize(800,350);
            p1.setLocationRelativeTo(null);
            dispose();
        }
    }
}
