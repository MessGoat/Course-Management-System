package AssignmentJava2;

import javax.naming.spi.DirStateFactory.Result;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.event.*; 

public class lecturerMAttendance extends JFrame implements ActionListener,ListSelectionListener{
    private JPanel sidePanel,mainPanel,pAll,p1,p2,p3,p4,p5;
    private JButton btnLPf,btnLC,btnLogOut,btnSubmit,btnCancel;
    private JLabel lblmTitle,lblStuList,lblDate,lblcTitle;
    private JList jlStuList;
    private JScrollPane sp1;
    private String courseID;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        lecturerMAttendance frame = new lecturerMAttendance();
        frame.setTitle("Mark Attendance");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
        
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
        
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }
    
    public lecturerMAttendance(){
        lblmTitle = new JLabel("Mark Attendance");
        btnLPf = new JButton("Profile");
        btnLC = new JButton("Course");
        btnLogOut = new JButton("Log Out");

        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        btnLPf.addActionListener(this);
        btnLC.addActionListener(this);
        btnLogOut.addActionListener(this);
        lblDate = new JLabel("Date(yyyy-mm-dd) :");
        lblStuList = new JLabel("Student List :");
        String [] stuData ={
            "20220001 Adam M",
            "20220002 Adam L",
            "20220003 Adam N",
        };
        jlStuList = new JList(stuData);
        sp1 = new JScrollPane(jlStuList);
        sp1.setBorder(new LineBorder(Color.gray,2));
        jlStuList.addListSelectionListener(this);
        btnSubmit = new JButton("Submit");
        btnCancel = new JButton("Cancel");
        btnSubmit.addActionListener(this);
        btnCancel.addActionListener(this);
        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.LEFT));
        p1.add(lblDate);
        p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.LEFT));
        p2.add(lblStuList);
        p3 = new JPanel();
        p3.setLayout(new BorderLayout());
        p3.add(jlStuList,BorderLayout.CENTER);
        p4 = new JPanel();
        p4.setLayout(new FlowLayout(FlowLayout.RIGHT));
        p4.add(btnSubmit);
        p4.add(btnCancel);
        p5 = new JPanel();
        p5.setLayout(new BorderLayout());
        p5.add(p2,BorderLayout.NORTH);
        p5.add(p3,BorderLayout.CENTER);
        p5.add(p4,BorderLayout.SOUTH);
        pAll = new JPanel();
        pAll.setLayout(new BorderLayout());
        pAll.add(p1,BorderLayout.NORTH);
        pAll.add(p5);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(3,1));
        sidePanel.add(btnLPf);
        sidePanel.add(btnLC);
        sidePanel.add(btnLogOut);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lblmTitle,BorderLayout.NORTH);
            lblmTitle.setFont(myFont);
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnLPf){
            String courseid = lblcTitle.getText();
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT u.Fname,u.Lname,u.ContactNo,u.Email,u.Address,u.IC,u.Gender,u.ResgistrationDate,l.LecturerID,l.Position,l.SchoolEmail,l.Department,l.Salary FROM userprofile u,lecturer l,course c WHERE u.IC = l.IC AND l.LecturerID = c.LecturerID AND CourseID =?");
                stmt.setString(1, courseid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String lecturerID = rs.getString("LecturerID");
                    String position = rs.getString("Position");
                    String schoolEmail = rs.getString("SchoolEmail");
                    String department = rs.getString("Department");
                    String salary = rs.getString("Salary");

                    lecturerProfile p1 = new lecturerProfile(firstName, lastName, gender, contactNo, email, ic, lecturerID, position, schoolEmail, department, salary);
                    p1.setTitle("Lecturer Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLC){
            String cid = lblcTitle.getText();
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT c.CourseID, c.CourseName, c.CreditHours, c.LecturerID FROM Course c,Lecturer l,userprofile p WHERE p.IC = l.IC AND l.LecturerID = c.LecturerID AND c.CourseID=?");
                stmt.setString(1, cid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String courseID = rs.getString("CourseID");
                    String courseName = rs.getString("CourseName");
                    int creditHour = rs.getInt("CreditHours");
                    String id = rs.getString("LecturerID");

                    lecturerCourse p1 = new lecturerCourse(id);
                    p1.setTitle("Lecturer Course");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            lecturerLogin p4 = new lecturerLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
        if(e.getSource()==btnCancel){
            String cid = lblcTitle.getText();
            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT c.CourseID, c.CourseName, c.CreditHours, c.LecturerID FROM Course c,Lecturer l,userprofile p WHERE p.IC = l.IC AND l.LecturerID = c.LecturerID AND c.CourseID=?");
                stmt.setString(1, cid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String courseID = rs.getString("CourseID");
                    String courseName = rs.getString("CourseName");
                    int creditHour = rs.getInt("CreditHours");
                    String id = rs.getString("LecturerID");

                    lecturerCourse p1 = new lecturerCourse(id);
                    p1.setTitle("Lecturer Course");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnSubmit){
            Object[] selectedItems = jlStuList.getSelectedValues();
            updateDatabase(selectedItems);
            JOptionPane.showMessageDialog(null,"Attendance Submitted.");
        }
    }

    public lecturerMAttendance(String courseid){
        this.courseID=courseid;
        try {
            Connect_DB();

            PreparedStatement stmt = conn.prepareStatement("SELECT s.StudentID, u.FName, u.LName,c.CourseID FROM StudentCourse c, Student s, UserProfile u WHERE s.StudentID = c.StudentID AND Attendance IS NULL AND u.IC = s.IC AND CourseID=?");
            stmt.setString(1, courseid);
            ResultSet rs = stmt.executeQuery();
            DefaultListModel<String> model = new DefaultListModel<>();
            while (rs.next()) {
                String courseID = rs.getString("CourseID");
                String studentID = rs.getString("StudentID");
                String fname = rs.getString("FName");
                String lname = rs.getString("LName");
                model.addElement(studentID + " " + fname + " " + lname);
            }
            lblcTitle = new JLabel(courseid);
            lblmTitle = new JLabel("Mark Attendance");
            btnLPf = new JButton("Profile");
            btnLC = new JButton("Course");
            btnLogOut = new JButton("Log Out");
            Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
            btnLPf.addActionListener(this);
            btnLC.addActionListener(this);
            btnLogOut.addActionListener(this);
            lblDate = new JLabel("");
            lblStuList = new JLabel("Student List :");
            jlStuList = new JList<>(model);
            jlStuList.setModel(model);
            sp1 = new JScrollPane(jlStuList);
            sp1.setBorder(new LineBorder(Color.gray,2));
            jlStuList.addListSelectionListener(this);
            btnSubmit = new JButton("Submit");
            btnCancel = new JButton("Cancel");
            btnSubmit.addActionListener(this);
            btnCancel.addActionListener(this);
            p1 = new JPanel();
            p1.setLayout(new FlowLayout(FlowLayout.LEFT));
            p1.add(lblDate);
            p2 = new JPanel();
            p2.setLayout(new FlowLayout(FlowLayout.LEFT));
            p2.add(lblStuList);
            p3 = new JPanel();
            p3.setLayout(new BorderLayout());
            p3.add(jlStuList,BorderLayout.CENTER);
            p4 = new JPanel();
            p4.setLayout(new FlowLayout(FlowLayout.RIGHT));
            p4.add(btnSubmit);
            p4.add(btnCancel);
            p5 = new JPanel();
            p5.setLayout(new BorderLayout());
            p5.add(p2,BorderLayout.NORTH);
            p5.add(p3,BorderLayout.CENTER);
            p5.add(p4,BorderLayout.SOUTH);
            pAll = new JPanel();
            pAll.setLayout(new BorderLayout());
            pAll.add(p1,BorderLayout.NORTH);
            pAll.add(p5);
            sidePanel = new JPanel();
            sidePanel.setLayout(new GridLayout(3,1));
            sidePanel.add(btnLPf);
            sidePanel.add(btnLC);
            sidePanel.add(btnLogOut);
            mainPanel = new JPanel();
            mainPanel.setLayout(new BorderLayout());
            mainPanel.add(lblmTitle,BorderLayout.NORTH);
                lblmTitle.setFont(myFont);
            mainPanel.add(pAll);
            add(sidePanel,BorderLayout.WEST);
            add(mainPanel);
    
            conn.close();
        } catch (Exception ex1) {
            ex1.printStackTrace();
        }
    }

    private void updateDatabase(Object[] selectedItems) {
        try {
            Connect_DB();

            PreparedStatement stmt = conn.prepareStatement("INSERT INTO StudentCourse (CourseID,StudentID,Attendance) VALUES(?,?,1);");
            for (Object selectedItem : selectedItems) {
                String studentID = selectedItem.toString().split(" ")[0];
                stmt.setString(1, courseID);
                stmt.setString(2, studentID);
                stmt.executeUpdate();
            }
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
            Object[] selectedItems = jlStuList.getSelectedValues();
        }
    }
}
