
DROP DATABASE CourseManagementSystem;
CREATE DATABASE CourseManagementSystem;
USE CourseManagementSystem;

#UserProfile

CREATE TABLE UserProfile(
FName VARCHAR(500),
LName VARCHAR(500),
ContactNo VARCHAR(500),
Email VARCHAR(500),
Address VARCHAR(500),
IC CHAR(14) NOT NULL,
Gender VARCHAR(100) CHECK(Gender IN('Male','Female')),
ResgistrationDate DATE,
Password VARCHAR(500),
PRIMARY KEY(IC)
);

/*Insert User(Student)*/
INSERT INTO UserProfile VALUES ('Nea','Karlsson','012-7323567','NNN123123@gmail.com','22A Jalan SP 7, Taman Connaught, 56000 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur','030401-14-2332','Female',STR_TO_DATE('2023-09-03','%Y-%m-%d'),'12345678');
INSERT INTO UserProfile VALUES ('Bryne','Liam','016-8399412','LiamBB2323@gmail.com','21B Jalan 3/144A, Taman Len Seng, 51000 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur','000121-14-1561','Male',STR_TO_DATE('2023-01-02','%Y-%m-%d'),'22222222');

/*Insert User(Lecturer)*/
INSERT INTO UserProfile VALUES('Kirra','Foster','011-8839901','KirKir@gmail.com','5 Jalan Midah 12b, Taman Midah, 56000 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur','910812-04-6220','Female',STR_TO_DATE('2000-08-03','%Y-%m-%d'),'88888888');
INSERT INTO UserProfile VALUES('Erik','Torsten','011-4422245','ErikTor3@gmail.com','993, Jalan Selesa 7, Taman Gembira, 58200 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur','930711-07-6881','Male',STR_TO_DATE('2001-08-03','%Y-%m-%d'),'87654321');

DESC UserProfile;

#Lecturer 	

CREATE TABLE Lecturer(
LecturerID CHAR(10) NOT NULL,
IC CHAR(14) NOT NULL,
Salary DECIMAL(10,2),
SchoolEmail VARCHAR(500) NOT NULL,
Department VARCHAR(500),
Position VARCHAR(500),
PRIMARY KEY(LecturerID),
FOREIGN KEY (IC) REFERENCES UserProfile (IC)
);

INSERT INTO Lecturer VALUES('L200000113','910812-04-6220','4100.00','L200000113@ucsicollege.edu.my','UCSI College Taman Connaught','Head Professor of DIT');
INSERT INTO Lecturer VALUES('L200100231','930711-07-6881','3500.00','L200100231@ucsicollege.edu.my','UCSI College Taman Connaught','Assistant Professor of DIT');

DESC Lecturer;

#Programme

CREATE TABLE Programme(
ProgrammeID VARCHAR(5) NOT NULL,
ProgrammeName VARCHAR(500),
Duration Decimal(2,1),
PRIMARY KEY(ProgrammeID)
);

INSERT INTO Programme VALUES('DIT','Diploma in Information Technology',2.5);
INSERT INTO Programme VALUES('DIS','Diploma in Information System',2);

DESC Programme;

#Student

CREATE TABLE Student(
StudentID CHAR(10) NOT NULL,
IC CHAR(14) NOT NULL,
Club VARCHAR(500),
SemIntake VARCHAR(500),
Scholarship Decimal(10,2),
ProgrammeID VARCHAR(5) NOT NULL,
PRIMARY KEY(StudentID),
FOREIGN KEY (IC) REFERENCES UserProfile (IC),
FOREIGN KEY (ProgrammeID) REFERENCES Programme (ProgrammeID)
);

INSERT INTO Student VALUES('2023000123','030401-14-2332','Home Economics','September 2023','0.5','DIT');
INSERT INTO Student VALUES('2024000334','000121-14-1561','Badminton','January 2024',null,'DIS');

DESC Student;


#Semester

CREATE TABLE Semester(
Batch VARCHAR(500) NOT NULL,
StartSem DATE,
EndSem DATE,
Year VARCHAR(500),
StudentID CHAR(10) NOT NULL,
PRIMARY KEY(Batch,StudentID),
FOREIGN KEY(StudentID) REFERENCES Student(StudentID)
);

INSERT INTO Semester VALUES('September 2023',STR_TO_DATE('2023-09-03','%Y-%m-%d'),STR_TO_DATE('2023-10-28','%Y-%m-%d'),'Year 1','2023000123');
INSERT INTO Semester VALUES('January 2024',STR_TO_DATE('2024-01-04','%Y-%m-%d'),STR_TO_DATE('2023-04-27','%Y-%m-%d'),'Year 1','2024000334');

DESC Semester;

#Course 

CREATE TABLE Course(
CourseID CHAR(7) NOT NULL,
CourseName VARCHAR(500),
CreditHours INT,
ProgrammeID VARCHAR(5) NOT NULL,
Batch VARCHAR(500) NOT NULL,
LecturerID CHAR(10) NOT NULL,
PRIMARY KEY(CourseID),
FOREIGN KEY(ProgrammeID) REFERENCES Programme(ProgrammeID),
FOREIGN KEY(Batch) REFERENCES Semester(Batch),
FOREIGN KEY(LecturerID) REFERENCES Lecturer(LecturerID)
);

INSERT INTO Course VALUES('DIT2274','Object-Oriented Programming',4,'DIT','September 2023','L200000113');
INSERT INTO Course VALUES('MPU2153','Philosophy and Current Issues',3,'DIS','January 2024','L200100231');
INSERT INTO Course VALUES('DIT2244','Multimedia Programming',4,'DIT','September 2023','L200000113');
INSERT INTO Course VALUES('DIT2254','Object-Oriented System Analysis & Design',4,'DIT','September 2023','L200100231');

DESC Course;

#Student Course

CREATE TABLE StudentCourse(
CourseID CHAR(7) NOT NULL,
StudentID CHAR(10) NOT NULL,
Attendance INT,
CommentDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY(CourseID) REFERENCES Course (CourseID),
FOREIGN KEY(StudentID) REFERENCES Student (StudentID)
);

DESC StudentCourse;

INSERT INTO StudentCourse (CourseID,StudentID) VALUES('DIT2274','2023000123');
INSERT INTO StudentCourse (CourseID,StudentID) VALUES('DIT2244','2023000123');
INSERT INTO StudentCourse (CourseID,StudentID) VALUES('DIT2254','2023000123');
INSERT INTO StudentCourse (CourseID,StudentID) VALUES('MPU2153','2024000334');

INSERT INTO StudentCourse (CourseID,StudentID,Attendance) VALUES('DIT2274','2023000123',1);
INSERT INTO StudentCourse (CourseID,StudentID,Attendance) VALUES('DIT2244','2023000123',1);
INSERT INTO StudentCourse (CourseID,StudentID,Attendance) VALUES('DIT2254','2023000123',1);
INSERT INTO StudentCourse (CourseID,StudentID,Attendance) VALUES('MPU2153','2024000334',1);

#Grade 

CREATE TABLE Grade(
CourseID CHAR(7) NOT NULL,
AssessmentMarks DECIMAL(10,2),
FinalMarks DECIMAL(10,2),
StudentID CHAR(10) NOT NULL,
FOREIGN KEY(CourseID) REFERENCES Course (CourseID),
FOREIGN KEY(StudentID) REFERENCES Student (StudentID)
);

INSERT INTO Grade VALUES('DIT2274',65.00,20.00,'2023000123');
INSERT INTO Grade VALUES('DIT2244',40.00,20.00,'2023000123');
INSERT INTO Grade VALUES('DIT2254',60.00,15.00,'2023000123');
INSERT INTO Grade VALUES('MPU2153',45.00,35.00,'2024000334');

DESC Grade;


#Bill

CREATE TABLE Bill( 
Invoice CHAR(8) NOT NULL,
OverheadBill DECIMAL(10,2),
PaidBIll DECIMAL(10,2),
StudentID CHAR(10) NOT NULL,
PRIMARY KEY(Invoice),   
FOREIGN KEY(StudentID) REFERENCES Student (StudentID)
);

INSERT INTO Bill VALUES('IN001001',2600.00,1300.00,'2023000123');
INSERT INTO Bill VALUES('IN001002',3200.00,3200.00,'2024000334');
INSERT INTO Bill VALUES('IN001003',3200.00,2600.00,'2024000334');

DESC Bill;

#Feedback

CREATE TABLE Feedback(
Comment VARCHAR(1000),
CommentDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
Rating INT,
StudentID CHAR(10) NOT NULL,
CourseID CHAR(7) NOT NULL,
FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
FOREIGN KEY(CourseID) REFERENCES Course (CourseID)
);

DESC Feedback;