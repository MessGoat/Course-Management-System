package AssignmentJava2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.event.*;
import javax.swing.border.LineBorder; 

public class studentBill extends JFrame implements ActionListener{
    private JPanel sidePanel,mainPanel,p1,p2,p3,p4,p5,pAll;
    private JButton btnPf,btnBill,btnC,btnLogOut;
    private JLabel lbl_bTitle,lblOB,lblPB,lblRB,lblInvoice,lblsID,lblstatus;
    private JTextField tfOB,tfPB,tfRB,tfinvoice,tfstatus;
    
    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;


    public static void main(String [] args){
        studentBill frame = new studentBill();
        frame.setTitle("Bill");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    //Connect Database Method
    public static void Connect_DB(){
        try{
            //1. Load Driver
            Class.forName(DRIVER);
    
            //2. Establish the connection
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
    
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }
    
    public studentBill(){
        lbl_bTitle = new JLabel("Bill");

        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");

        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        Font myFont2 = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 40);

        lblOB = new JLabel("Overhead Bill :");
        lblPB = new JLabel("Paid Bill :");
        lblRB = new JLabel("Remaining Bill :");
        lblInvoice = new JLabel("Invoice :");

        tfOB = new JTextField(25);
        tfPB = new JTextField(28);
        tfRB = new JTextField(25);
        
        tfOB.setEditable(false);
        tfPB.setEditable(false);
        tfRB.setEditable(false);

        tfinvoice = new JTextField(40);
        tfinvoice.setEditable(false);
        tfinvoice.setFont(myFont2);

        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);

        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p1.add(lblOB);
        p1.add(tfOB);

        p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p2.add(lblPB);
        p2.add(tfPB);

        p3 = new JPanel();
        p3.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p3.add(lblRB);
        p3.add(tfRB);

        p5 = new JPanel();
        p5.setLayout(new BorderLayout());
        p5.add(lblInvoice,BorderLayout.NORTH);
        p5.add(tfinvoice);
        tfinvoice.setBorder(new LineBorder(Color.gray,5));

        pAll = new JPanel();
        pAll.setLayout(new GridLayout(4,1));
        pAll.add(p1);
        pAll.add(p2);
        pAll.add(p3);
        pAll.add(p5);

        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);

        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_bTitle,BorderLayout.NORTH);
            lbl_bTitle.setFont(myFont);
        mainPanel.add(pAll);

        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnPf){
            String id = lblsID.getText();

            try{
                Connect_DB();

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Student s,userProfile u WHERE s.IC=u.IC AND s.StudentID=?");
                stmt.setString(1, id);

                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    //Extract the lecturer information to other class
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String studentID = rs.getString("StudentID");
                    String intake = rs.getString("SemIntake");
                    String club = rs.getString("Club");
                    double scholarship = rs.getDouble("Scholarship");
                    String register = rs.getString("ResgistrationDate");
                    String address = rs.getString("Address");

                    studentProfile p1 = new studentProfile(firstName, lastName, gender, contactNo, email, ic, address, register, studentID, intake, club,scholarship);
                    p1.setTitle("Student Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }

                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnC){
            String invoice = tfinvoice.getText();
            try{
                Connect_DB();
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Bill b,Student s WHERE b.StudentID = s.StudentID AND Invoice=?");
                stmt.setString(1,invoice);
                ResultSet rs = stmt.executeQuery();

                if(rs.next()){
                    String id = rs.getString("StudentID");
                    studentCourse p1 = new studentCourse(id);
                    p1.setTitle("Student Course");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }

        }
        if(e.getSource()==btnBill){
            JOptionPane.showMessageDialog(null,"You already in the Student Bill page.");
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            studentLogin p4 = new studentLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
    }

    public studentBill(String studentID){
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(0, 1));
        try{
            Connect_DB();

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Bill WHERE StudentID=?");
            stmt.setString(1, studentID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String invoice = rs.getString("Invoice");
                double over = rs.getDouble("OverheadBill");
                double paid = rs.getDouble("PaidBill");
                JPanel billPanel = createBillPanel(studentID,invoice,over,paid);
                mainPanel.add(billPanel);
            }
            add(mainPanel);
        }catch(Exception ex1){
            ex1.printStackTrace();
        }
        add(new JScrollPane(mainPanel)); 
    }

    public JPanel createBillPanel(String id,String inv,double over, double paid){
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        lbl_bTitle = new JLabel("Bill");
        lblsID = new JLabel(id);
        btnPf = new JButton("Profile");
        btnBill = new JButton("Bill");
        btnC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        Font myFont2 = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 40);
        lblOB = new JLabel("Overhead Bill :");
        lblPB = new JLabel("Paid Bill :");
        lblRB = new JLabel("Remaining Bill :");
        lblInvoice = new JLabel("Invoice :");
        lblstatus = new JLabel("Status : ");
        tfstatus = new JTextField(25);
            tfstatus.setEditable(false);
        tfOB = new JTextField(25);
        tfPB = new JTextField(28);
        tfRB = new JTextField(25);
        tfOB.setEditable(false);
        tfPB.setEditable(false);
        tfRB.setEditable(false);
        tfinvoice = new JTextField(40);
        tfinvoice.setEditable(false);
        tfinvoice.setFont(myFont2);
        btnPf.addActionListener(this);
        btnBill.addActionListener(this);
        btnC.addActionListener(this);
        btnLogOut.addActionListener(this);
        p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p1.add(lblOB);
        p1.add(tfOB);
        p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p2.add(lblPB);
        p2.add(tfPB);
        p3 = new JPanel();
        p3.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p3.add(lblRB);
        p3.add(tfRB);
        p5 = new JPanel();
        p5.setLayout(new BorderLayout());
        p5.add(lblInvoice,BorderLayout.NORTH);
        p5.add(tfinvoice);
        tfinvoice.setBorder(new LineBorder(Color.gray,5));
        pAll = new JPanel();
        pAll.setLayout(new GridLayout(5,1));
        pAll.add(p5);
        pAll.add(p1);
        pAll.add(p2);
        pAll.add(p3);
        p4 = new JPanel();
        p4.setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
        p4.add(lblstatus);
        p4.add(tfstatus);
        pAll.add(p4);
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(4,1));
        sidePanel.add(btnPf);
        sidePanel.add(btnBill);
        sidePanel.add(btnC);
        sidePanel.add(btnLogOut);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(pAll);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);

        tfOB.setText("RM"+over);
        tfinvoice.setText(inv);
        tfPB.setText("RM"+paid);
        double remain = over - paid;
        tfRB.setText("RM"+remain);

        if(remain==0){
            tfstatus.setText("Completed");
        }else{
            tfstatus.setText("Pending...");
        }

        return mainPanel;
    }
}
