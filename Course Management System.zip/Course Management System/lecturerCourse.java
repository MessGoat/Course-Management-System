package AssignmentJava2;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class lecturerCourse extends JFrame implements ActionListener{
    private JPanel sidePanel,mainPanel,cp1,cp1_3,cp1_4,pManage;
    private JButton btnLPf,btnLC,btnLogOut,btnStuList,btnGrading;
    private JLabel lbl_cTitle,lblCID,lblCName,lblCredit,lblNumS,lblYear;
    private JTextField tfCID,tfCName,tfCredit,tfNumS,tfYear;
    private String courseID;

    static final String DRIVER ="com.mysql.cj.jdbc.Driver";
    static final String DB_URL ="jdbc:mysql://localhost:3306/coursemanagementsystem?serverTimezone=UTC";
    static Connection conn = null;

    public static void main(String [] args){
        lecturerCourse frame = new lecturerCourse();
        frame.setTitle("Lecturer Course");
        frame.setSize(800,350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    }
    public lecturerCourse(){
        lbl_cTitle = new JLabel("Course");
        btnLPf = new JButton("Profile");
        btnLC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lblCID = new JLabel("CourseID :");
        lblCName = new JLabel("CourseName :");
        lblCredit = new JLabel("CreditHour");
        lblNumS = new JLabel("Number of Student :");
        lblYear = new JLabel("Year :");
        tfCID = new JTextField(10);     
        tfCName = new JTextField(10); 
        tfCredit = new JTextField(10); 
        tfNumS = new JTextField(10); 
        tfYear = new JTextField(8);
        btnStuList = new JButton("Student List");
        btnGrading = new JButton("Grading");
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(3,1));
        sidePanel.add(btnLPf);
        sidePanel.add(btnLC);
        sidePanel.add(btnLogOut);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        cp1 = new JPanel();
        cp1.setLayout(new GridLayout(3,4));
        cp1.add(lblCID);
        cp1.add(tfCID);
            tfCID.setEditable(false);
        cp1.add(lblCredit);
        cp1.add(tfCredit);
            tfCredit.setEditable(false);
        cp1.add(lblCName);
        cp1.add(tfCName);
            tfCName.setEditable(false);
        cp1.add(lblNumS);
        cp1.add(tfNumS);  
            tfNumS.setEditable(false);
        cp1.add(lblYear);
        cp1.add(tfYear);
            tfYear.setEditable(false);
        cp1_3 = new JPanel();
        cp1_3.setLayout(new FlowLayout(FlowLayout.RIGHT,10,0));
        cp1_3.add(btnStuList);
        cp1_3.add(btnGrading);
        cp1_4 = new JPanel();
        cp1_4.setLayout(new GridLayout(2,1));
        cp1_4.setBorder(new LineBorder(Color.gray,5));
        cp1_4.add(cp1);
        cp1_4.add(cp1_3);
        pManage = new JPanel();
        pManage.setLayout(new GridLayout(1,1));
        pManage.add(cp1_4);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_cTitle,BorderLayout.NORTH);
            lbl_cTitle.setFont(myFont);
        mainPanel.add(pManage);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);
    }

    public static void Connect_DB(){
        try{
            Class.forName(DRIVER);
        
            conn = DriverManager.getConnection(DB_URL,"root","");
            System.out.println("Connected to database");
        
        } catch(ClassNotFoundException ex){
            System.err.println("Error loading MySQL JDBC driver: " + ex.getMessage());
        } catch(SQLException ex){
            System.err.println("Error connecting to the database: " + ex.getMessage());
        }
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btnLPf){
            String courseid = tfCID.getText();
            try{
                Connect_DB();
                PreparedStatement stmt = conn.prepareStatement("SELECT u.Fname,u.Lname,u.ContactNo,u.Email,u.Address,u.IC,u.Gender,u.ResgistrationDate,l.LecturerID,l.Position,l.SchoolEmail,l.Department,l.Salary FROM userprofile u,lecturer l,course c WHERE u.IC = l.IC AND l.LecturerID = c.LecturerID AND CourseID =?");
                stmt.setString(1, courseid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String firstName = rs.getString("FName");
                    String lastName = rs.getString("LName");
                    String gender = rs.getString("Gender");
                    String contactNo = rs.getString("ContactNo");
                    String email = rs.getString("Email");
                    String ic = rs.getString("IC");
                    String lecturerID = rs.getString("LecturerID");
                    String position = rs.getString("Position");
                    String schoolEmail = rs.getString("SchoolEmail");
                    String department = rs.getString("Department");
                    String salary = rs.getString("Salary");
                    lecturerProfile p1 = new lecturerProfile(firstName, lastName, gender, contactNo, email, ic, lecturerID, position, schoolEmail, department, salary);
                    p1.setTitle("Lecturer Profile");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }
        }
        if(e.getSource()==btnLC){
            JOptionPane.showMessageDialog(null,"You already in the Lecturer Course page.");
        }
        if(e.getSource()==btnLogOut){
            JOptionPane.showMessageDialog(null, "You have logged out.");
            lecturerLogin p4 = new lecturerLogin();
            p4.setTitle("Login");
            p4.setVisible(true);
            p4.setSize(800,350);
            p4.setLocationRelativeTo(null);
            dispose();
        }
    }

    public lecturerCourse(String lecturerID) {
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(0, 1));
        try {
            Connect_DB();
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Course WHERE LecturerID = ?");
            stmt.setString(1, lecturerID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String courseID = rs.getString("CourseID");
                String courseName = rs.getString("CourseName");
                int creditHour = rs.getInt("CreditHours");
                JPanel coursePanel = createCoursePanel(courseID, courseName, creditHour);
                mainPanel.add(coursePanel);
                PreparedStatement stmt1 = conn.prepareStatement("SELECT CourseID, COUNT(DISTINCT StudentID) AS Num_Students FROM studentcourse WHERE Attendance IS NULL AND CourseID=? GROUP BY CourseID;");
                stmt1.setString(1,courseID);
                ResultSet rs2 = stmt1.executeQuery();
                if (rs2.next()) {
                    int numStudents = rs2.getInt("Num_Students");
                    tfNumS.setText(""+numStudents);
                }
            }
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        add(new JScrollPane(mainPanel)); 
    }

    public JPanel createCoursePanel(String courseID, String courseName, int creditHour) {
        this.courseID=courseID;
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        lbl_cTitle = new JLabel("Course : "+courseName);
        btnLPf = new JButton("Profile");
        btnLC = new JButton("Course");
        btnLogOut = new JButton("Log Out");
        lblCID = new JLabel("CourseID :");
        lblCName = new JLabel("CourseName :");
        lblCredit = new JLabel("CreditHour");
        lblNumS = new JLabel("Number of Student :");
        lblYear = new JLabel("Year :");
        tfCID = new JTextField(10);     
        tfCName = new JTextField(10); 
        tfCredit = new JTextField(10); 
        tfNumS = new JTextField(10); 
        tfYear = new JTextField(8);
        btnStuList = new JButton("Student List");
        btnGrading = new JButton("Grading");
        sidePanel = new JPanel();
        sidePanel.setLayout(new GridLayout(3,1));
        sidePanel.add(btnLPf);
        sidePanel.add(btnLC);
        sidePanel.add(btnLogOut);
        Font myFont = new Font("SansSerif ", Font.BOLD + Font.ITALIC, 20);
        cp1 = new JPanel();
        cp1.setLayout(new GridLayout(2,4));
        cp1.add(lblCID);
        cp1.add(tfCID);
            tfCID.setEditable(false);
        cp1.add(lblCredit);
        cp1.add(tfCredit);
            tfCredit.setEditable(false);
        cp1.add(lblCName);
        cp1.add(tfCName);
            tfCName.setEditable(false);
        cp1.add(lblNumS);
        cp1.add(tfNumS);  
            tfNumS.setEditable(false);
        cp1_3 = new JPanel();
        cp1_3.setLayout(new FlowLayout(FlowLayout.RIGHT,10,0));
        cp1_3.add(btnStuList);
        cp1_3.add(btnGrading);
        cp1_4 = new JPanel();
        cp1_4.setLayout(new GridLayout(2,1));
        cp1_4.setBorder(new LineBorder(Color.gray,5));
        cp1_4.add(cp1);
        cp1_4.add(cp1_3);
        pManage = new JPanel();
        pManage.setLayout(new GridLayout(1,1));
        pManage.add(cp1_4);
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(lbl_cTitle,BorderLayout.NORTH);
            lbl_cTitle.setFont(myFont);
        mainPanel.add(pManage);
        add(sidePanel,BorderLayout.WEST);
        add(mainPanel);

        tfCID.setText(courseID);
        tfCName.setText(courseName);
        tfCredit.setText(""+creditHour);

        btnStuList.addActionListener(this);
        btnGrading.addActionListener(this);
        btnLPf.addActionListener(this);
        btnLC.addActionListener(this);
        btnLogOut.addActionListener(this);

        btnStuList.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            try{
                Connect_DB();
                PreparedStatement stmt = conn.prepareStatement("SELECT c.CourseID,c.StudentID,c.Attendance FROM StudentCourse c,Student s WHERE c.StudentID = s.StudentID AND CourseID =?");
                stmt.setString(1, courseID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String cid = rs.getString("CourseID");
                    String sid = rs.getString("StudentID");
                    int attendance = rs.getInt("Attendance");

                    lecturerStuList p1 = new lecturerStuList(cid);
                    p1.setTitle("Student List");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }}});
    
        btnGrading.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            try{
                Connect_DB();
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Grade WHERE CourseID=?");
                stmt.setString(1, courseID);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    String id = rs.getString("CourseID");
                    double amarks = rs.getDouble("AssessmentMarks");
                    double fmarks = rs.getDouble("FinalMarks");
                    String studentID = rs.getString("StudentID");

                    lecturerGrading p1 = new lecturerGrading(id);
                    p1.setTitle("Grade");
                    p1.setVisible(true);
                    p1.setSize(800,350);
                    p1.setLocationRelativeTo(null);
                    dispose();
                }
                conn.close();
            }catch(Exception ex1){
                ex1.printStackTrace();
            }}});
        return mainPanel;
    }

}
